package com.eduspark.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import io.jsonwebtoken.security.Keys;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;

@Component
public class JwtUtil {

    @Value("${app.jwt.secret}")
    private String secret;

    @Value("${app.jwt.expiration}")
    private long expiration;

    private Key getKey() {

        return Keys.hmacShaKeyFor(
                secret.getBytes()
        );
    }

    // Generate JWT Token
    public String generateToken(
            String email,
            String role,
            Long userId
    ) {

        return Jwts.builder()

                .setSubject(email)

                .claim("role", role)

                .claim("userId", userId)

                .setIssuedAt(new Date())

                .setExpiration(
                        new Date(
                                System.currentTimeMillis()
                                        + expiration
                        )
                )

                .signWith(
                        getKey(),
                        SignatureAlgorithm.HS256
                )

                .compact();
    }

    // Extract Email
    public String extractEmail(String token) {

        return extractClaims(token)
                .getSubject();
    }

    // Extract Role
    public String extractRole(String token) {

        return extractClaims(token)
                .get("role", String.class);
    }

    // Extract UserId
    public Long extractUserId(String token) {

        return extractClaims(token)
                .get("userId", Long.class);
    }

    // Validate Token
    public boolean isValid(String token) {

        try {

            extractClaims(token);

            return true;

        } catch (Exception e) {

            return false;
        }
    }

    // Extract Claims
    private Claims extractClaims(String token) {

        return Jwts.parserBuilder()

                .setSigningKey(getKey())

                .build()

                .parseClaimsJws(token)

                .getBody();
    }
}