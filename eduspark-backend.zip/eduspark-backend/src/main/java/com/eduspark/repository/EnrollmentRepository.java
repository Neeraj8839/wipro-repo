package com.eduspark.repository;

import com.eduspark.entity.Enrollment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {

    List<Enrollment> findByStudentId(Long studentId);

    List<Enrollment> findByCourseId(Long courseId);

    Optional<Enrollment> findByStudentIdAndCourseId(Long studentId, Long courseId);

    boolean existsByStudentIdAndCourseId(Long studentId, Long courseId);

    int countByCourseId(Long courseId);

    long countDistinctByPaymentStatus(Enrollment.PaymentStatus paymentStatus);

    @Transactional
    void deleteByStudentId(Long studentId);


    @Query("""
       SELECT COALESCE(SUM(e.amountPaid),0)
       FROM Enrollment e
       WHERE e.paymentStatus='COMPLETED'
       """)
    Double getTotalRevenue();
}