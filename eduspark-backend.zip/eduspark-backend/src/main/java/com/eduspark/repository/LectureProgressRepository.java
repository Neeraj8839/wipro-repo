package com.eduspark.repository;

import com.eduspark.entity.LectureProgress;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

public interface LectureProgressRepository extends JpaRepository<LectureProgress, Long> {

    List<LectureProgress> findByStudentId(Long studentId);

    Optional<LectureProgress> findByStudentIdAndLectureId(Long studentId, Long lectureId);

    List<LectureProgress> findByStudentIdAndCompleted(Long studentId, boolean completed);

    @Query("""
            SELECT lp
            FROM LectureProgress lp
            WHERE lp.student.id = ?1
            AND lp.lecture.course.id = ?2
            """)
    List<LectureProgress> findByStudentIdAndCourseId(Long studentId, Long courseId);

    @Query("""
            SELECT COUNT(lp)
            FROM LectureProgress lp
            WHERE lp.student.id = ?1
            AND lp.lecture.course.id = ?2
            AND lp.completed = true
            """)
    long countCompletedByStudentAndCourse(Long studentId, Long courseId);


    @Query("""
SELECT lp
FROM LectureProgress lp
WHERE lp.student.id = ?1
ORDER BY lp.completedAt DESC
""")
    List<LectureProgress> findRecentProgress(Long studentId);

    @Transactional
    void deleteByStudentId(Long studentId);
}