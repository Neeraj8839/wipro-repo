package com.eduspark.repository;

import com.eduspark.entity.Quiz;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface QuizRepository extends JpaRepository<Quiz, Long> {

    List<Quiz> findByLectureId(Long lectureId);

    List<Quiz> findByLecture_Course_Id(Long courseId);
}