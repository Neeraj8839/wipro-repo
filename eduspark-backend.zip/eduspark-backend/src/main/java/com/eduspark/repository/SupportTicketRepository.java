package com.eduspark.repository;

import com.eduspark.entity.SupportTicket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface SupportTicketRepository extends JpaRepository<SupportTicket, Long> {

    List<SupportTicket> findByStudentIdOrderByCreatedAtDesc(Long studentId);

    List<SupportTicket> findByStatusOrderByCreatedAtDesc(
            SupportTicket.Status status
    );

    List<SupportTicket> findAllByOrderByCreatedAtDesc();

    int countByStatus(SupportTicket.Status status);

    @Transactional
    void deleteByStudentId(Long studentId);
}