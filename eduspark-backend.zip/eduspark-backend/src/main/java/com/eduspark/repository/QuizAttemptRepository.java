package com.eduspark.repository;

import com.eduspark.entity.QuizAttempt;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface QuizAttemptRepository extends JpaRepository<QuizAttempt, Long> {

    List<QuizAttempt> findByStudentIdAndQuizId(Long studentId, Long quizId);

    List<QuizAttempt> findByStudentId(Long studentId);

    @Query("""
            SELECT COUNT(qa)
            FROM QuizAttempt qa
            WHERE qa.student.id = ?1
            AND qa.correct = true
            """)
    long countCorrectByStudent(Long studentId);

    @Transactional
    void deleteByStudentId(Long studentId);
}