package com.eduspark.repository;

import com.eduspark.entity.Course;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CourseRepository extends JpaRepository<Course, Long> {

    List<Course> findByStatus(Course.Status status);

    List<Course> findByCategory(String category);

    List<Course> findByTitleContainingIgnoreCase(String title);

    List<Course> findByStatusOrderByCreatedAtDesc(Course.Status status);
}