package com.eduspark.repository;

import com.eduspark.entity.Lecture;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LectureRepository
        extends JpaRepository<Lecture, Long> {

    List<Lecture> findByCourseId(Long courseId);

    List<Lecture> findByCourseIdOrderByOrderIndexAsc(Long courseId);

    long countByCourseId(Long courseId);
}