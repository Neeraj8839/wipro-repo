package com.eduspark.config;

import com.eduspark.entity.*;
import com.eduspark.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import com.eduspark.repository.QuizRepository;

import java.math.BigDecimal;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final CourseRepository courseRepository;
    private final LectureRepository lectureRepository;
    private final QuizRepository quizRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {

        if (userRepository.count() > 0) return;

        // ADMIN
        User admin = User.builder()
                .firstName("Admin")
                .lastName("EduSpark")
                .email("admin@eduspark.com")
                .password(passwordEncoder.encode("admin123"))
                .role(User.Role.ADMIN)
                .active(true)
                .build();
        userRepository.save(admin);

        // STUDENT
        User student = User.builder()
                .firstName("Alex")
                .lastName("Johnson")
                .email("student@eduspark.com")
                .password(passwordEncoder.encode("student123"))
                .role(User.Role.STUDENT)
                .active(true)
                .build();
        userRepository.save(student);

        // COURSE 1
        Course c1 = Course.builder()
                .title("Complete Web Development Bootcamp")
                .description("Learn HTML, CSS, JavaScript, React and Node.js from scratch.")
                .price(new BigDecimal("49.99"))
                .category("Web Development")
                .instructor("Sarah Connor")
                .durationHours(40)
                .status(Course.Status.PUBLISHED)
                .thumbnailUrl("https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=400")
                .build();
        courseRepository.save(c1);

        // COURSE 2
        Course c2 = Course.builder()
                .title("Python for Data Science & AI")
                .description("Master Python, Pandas, NumPy, Machine Learning and Deep Learning.")
                .price(new BigDecimal("59.99"))
                .category("Data Science")
                .instructor("Dr. James Park")
                .durationHours(35)
                .status(Course.Status.PUBLISHED)
                .thumbnailUrl("https://images.unsplash.com/photo-1527474305487-b87b222841cc?w=400")
                .build();
        courseRepository.save(c2);

        // COURSE 3
        Course c3 = Course.builder()
                .title("UI/UX Design Masterclass")
                .description("Design beautiful interfaces with Figma.")
                .price(new BigDecimal("39.99"))
                .category("Design")
                .instructor("Maria Santos")
                .durationHours(25)
                .status(Course.Status.PUBLISHED)
                .thumbnailUrl("https://images.unsplash.com/photo-1561070791-2526d30994b5?w=400")
                .build();
        courseRepository.save(c3);

        // ------------------------
        // COURSE 1 LECTURES
        // ------------------------

        String[] webLectures = {
                "Introduction & Setup",
                "HTML Fundamentals",
                "CSS Mastery",
                "JavaScript Basics",
                "React Project"
        };

        int idx = 1;

        for (String title : webLectures) {

            lectureRepository.save(
                    Lecture.builder()
                            .course(c1)
                            .title(title)
                            .description(title)
                            .videoUrl("https://www.youtube.com/embed/dQw4w9WgXcQ")
                            .durationMinutes(30)
                            .orderIndex(idx++)
                            .freePreview(idx == 1)
                            .type(Lecture.LectureType.VIDEO)
                            .build()
            );
        }

        // ------------------------
        // COURSE 2 LECTURES
        // ------------------------

        lectureRepository.save(
                Lecture.builder()
                        .course(c2)
                        .title("Python Introduction")
                        .description("Getting Started With Python")
                        .videoUrl("https://www.youtube.com/embed/dQw4w9WgXcQ")
                        .durationMinutes(20)
                        .orderIndex(1)
                        .freePreview(true)
                        .type(Lecture.LectureType.VIDEO)
                        .build()
        );

        lectureRepository.save(
                Lecture.builder()
                        .course(c2)
                        .title("Variables & Data Types")
                        .description("Learn Python Variables")
                        .videoUrl("https://www.youtube.com/embed/dQw4w9WgXcQ")
                        .durationMinutes(25)
                        .orderIndex(2)
                        .freePreview(false)
                        .type(Lecture.LectureType.VIDEO)
                        .build()
        );

        lectureRepository.save(
                Lecture.builder()
                        .course(c2)
                        .title("NumPy Basics")
                        .description("NumPy Introduction")
                        .videoUrl("https://www.youtube.com/embed/dQw4w9WgXcQ")
                        .durationMinutes(30)
                        .orderIndex(3)
                        .freePreview(false)
                        .type(Lecture.LectureType.VIDEO)
                        .build()
        );

        // ------------------------
        // COURSE 3 LECTURES
        // ------------------------

        lectureRepository.save(
                Lecture.builder()
                        .course(c3)
                        .title("Figma Basics")
                        .description("Getting Started With Figma")
                        .videoUrl("https://www.youtube.com/embed/dQw4w9WgXcQ")
                        .durationMinutes(20)
                        .orderIndex(1)
                        .freePreview(true)
                        .type(Lecture.LectureType.VIDEO)
                        .build()
        );

        lectureRepository.save(
                Lecture.builder()
                        .course(c3)
                        .title("Wireframing")
                        .description("Learn Wireframing")
                        .videoUrl("https://www.youtube.com/embed/dQw4w9WgXcQ")
                        .durationMinutes(25)
                        .orderIndex(2)
                        .freePreview(false)
                        .type(Lecture.LectureType.VIDEO)
                        .build()
        );

        lectureRepository.save(
                Lecture.builder()
                        .course(c3)
                        .title("Prototyping")
                        .description("Interactive Prototype Design")
                        .videoUrl("https://www.youtube.com/embed/dQw4w9WgXcQ")
                        .durationMinutes(35)
                        .orderIndex(3)
                        .freePreview(false)
                        .type(Lecture.LectureType.VIDEO)
                        .build()
        );


        // ==========================
// QUIZZES FOR WEB DEVELOPMENT
// ==========================

        Lecture htmlLecture =
                lectureRepository.findByCourseId(c1.getId()).get(1);

        quizRepository.save(
                Quiz.builder()
                        .lecture(htmlLecture)
                        .question("What does HTML stand for?")
                        .optionA("Hyper Text Markup Language")
                        .optionB("Home Tool Markup Language")
                        .optionC("Hyperlinks Text Markup Language")
                        .optionD("High Text Machine Language")
                        .correctAnswer("Hyper Text Markup Language")
                        .build()
        );

        quizRepository.save(
                Quiz.builder()
                        .lecture(htmlLecture)
                        .question("Which tag creates a hyperlink?")
                        .optionA("<p>")
                        .optionB("<img>")
                        .optionC("<a>")
                        .optionD("<link>")
                        .correctAnswer("<a>")
                        .build()
        );

        Lecture cssLecture =
                lectureRepository.findByCourseId(c1.getId()).get(2);

        quizRepository.save(
                Quiz.builder()
                        .lecture(cssLecture)
                        .question("Which property changes text color?")
                        .optionA("background")
                        .optionB("font-size")
                        .optionC("color")
                        .optionD("text-style")
                        .correctAnswer("color")
                        .build()
        );

        quizRepository.save(
                Quiz.builder()
                        .lecture(cssLecture)
                        .question("Which CSS property controls spacing inside an element?")
                        .optionA("margin")
                        .optionB("padding")
                        .optionC("border")
                        .optionD("width")
                        .correctAnswer("padding")
                        .build()
        );

        Lecture jsLecture =
                lectureRepository.findByCourseId(c1.getId()).get(3);

        quizRepository.save(
                Quiz.builder()
                        .lecture(jsLecture)
                        .question("Which keyword declares a variable?")
                        .optionA("let")
                        .optionB("create")
                        .optionC("int")
                        .optionD("new")
                        .correctAnswer("let")
                        .build()
        );

        quizRepository.save(
                Quiz.builder()
                        .lecture(jsLecture)
                        .question("JavaScript runs in?")
                        .optionA("Browser")
                        .optionB("Database")
                        .optionC("Compiler")
                        .optionD("Photoshop")
                        .correctAnswer("Browser")
                        .build()
        );

// ==========================
// PYTHON COURSE QUIZZES
// ==========================

        Lecture pythonLecture =
                lectureRepository.findByCourseId(c2.getId()).get(0);

        quizRepository.save(
                Quiz.builder()
                        .lecture(pythonLecture)
                        .question("Python is?")
                        .optionA("Programming Language")
                        .optionB("Database")
                        .optionC("Browser")
                        .optionD("Framework")
                        .correctAnswer("Programming Language")
                        .build()
        );

        quizRepository.save(
                Quiz.builder()
                        .lecture(pythonLecture)
                        .question("Which function prints output?")
                        .optionA("echo")
                        .optionB("printf")
                        .optionC("print")
                        .optionD("display")
                        .correctAnswer("print")
                        .build()
        );

// ==========================
// UI UX COURSE QUIZZES
// ==========================

        Lecture figmaLecture =
                lectureRepository.findByCourseId(c3.getId()).get(0);

        quizRepository.save(
                Quiz.builder()
                        .lecture(figmaLecture)
                        .question("Figma is mainly used for?")
                        .optionA("UI Design")
                        .optionB("Database")
                        .optionC("Backend")
                        .optionD("Hosting")
                        .correctAnswer("UI Design")
                        .build()
        );

        quizRepository.save(
                Quiz.builder()
                        .lecture(figmaLecture)
                        .question("Wireframes are?")
                        .optionA("Final Design")
                        .optionB("Blueprint Layout")
                        .optionC("Database Schema")
                        .optionD("Server Config")
                        .correctAnswer("Blueprint Layout")
                        .build()
        );

        log.info("EduSpark sample data initialized");
    }
}