package com.eduspark.controller;

import com.eduspark.dto.CourseDto;
import com.eduspark.security.JwtUtil;
import com.eduspark.service.CourseService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class CourseController {

    private final CourseService courseService;
    private final JwtUtil jwtUtil;

    @GetMapping("/courses/public/all")
    public ResponseEntity<List<CourseDto>> getPublishedCourses() {
        return ResponseEntity.ok(courseService.getPublishedCourses());
    }

    @GetMapping("/courses/public/{id}")
    public ResponseEntity<CourseDto> getPublicCourse(@PathVariable Long id) {
        return ResponseEntity.ok(courseService.getCourseById(id, null));
    }

    @GetMapping("/courses/{id}")
    public ResponseEntity<CourseDto> getCourse(@PathVariable Long id, Authentication auth) {
        Long userId = getUserId(auth);
        return ResponseEntity.ok(courseService.getCourseById(id, userId));
    }

    @GetMapping("/courses")
    public ResponseEntity<List<CourseDto>> getMyCourses() {
        return ResponseEntity.ok(courseService.getPublishedCourses());
    }

    private Long getUserId(Authentication auth) {
        if (auth == null) return null;
        return (Long) ((org.springframework.security.authentication.UsernamePasswordAuthenticationToken) auth).getDetails();
    }
}
