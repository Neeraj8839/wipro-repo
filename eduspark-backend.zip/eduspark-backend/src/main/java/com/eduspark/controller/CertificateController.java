package com.eduspark.controller;

import com.eduspark.dto.CertificateDto;
import com.eduspark.service.CertificateService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/student")
@RequiredArgsConstructor
public class CertificateController {

    private final CertificateService certificateService;

    @GetMapping("/certificate/{courseId}")
    public CertificateDto getCertificate(
            @PathVariable Long courseId,
            Authentication auth
    ) {

        Long userId =
                (Long)
                        ((UsernamePasswordAuthenticationToken) auth)
                                .getDetails();

        return certificateService.generateCertificate(
                userId,
                courseId
        );
    }
}