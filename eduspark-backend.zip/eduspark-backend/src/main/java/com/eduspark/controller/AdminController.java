package com.eduspark.controller;

import com.eduspark.dto.*;
import com.eduspark.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {

    private final AdminService adminService;
    private final CourseService courseService;
    private final EnrollmentService enrollmentService;
    private final TicketService ticketService;
    private final LectureService lectureService;

    @GetMapping("/dashboard")
    public ResponseEntity<AdminDashboardDto> dashboard() {
        return ResponseEntity.ok(adminService.getDashboard());
    }


    @GetMapping("/analytics")
    public ResponseEntity<AdminAnalyticsDto> getAnalytics() {

        return ResponseEntity.ok(
                adminService.getAnalytics()
        );
    }

    // Students
    @GetMapping("/students")
    public ResponseEntity<List<StudentProfileDto>> getAllStudents() {
        return ResponseEntity.ok(adminService.getAllStudents());
    }


    @PostMapping("/students")
    public ResponseEntity<StudentProfileDto> createStudent(
            @RequestBody CreateStudentRequest request
    ) {

        return ResponseEntity.ok(
                adminService.createStudent(request)
        );
    }

    @GetMapping("/students/{id}")
    public ResponseEntity<StudentProfileDto> getStudent(@PathVariable Long id) {
        return ResponseEntity.ok(adminService.getStudentProfile(id));
    }

    @DeleteMapping("/students/{id}")
    public ResponseEntity<Void> deleteStudent(@PathVariable Long id) {
        adminService.deleteStudent(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/students/{id}/status")
    public ResponseEntity<StudentProfileDto> updateStudentStatus(@PathVariable Long id, @RequestParam boolean active) {
        return ResponseEntity.ok(adminService.updateStudentStatus(id, active));
    }


    @PutMapping("/students/{id}")
    public ResponseEntity<StudentProfileDto> updateStudent(
            @PathVariable Long id,
            @RequestBody UpdateStudentRequest request
    ) {

        return ResponseEntity.ok(
                adminService.updateStudent(
                        id,
                        request
                )
        );
    }

    // Courses
    @GetMapping("/courses")
    public ResponseEntity<List<CourseDto>> getAllCourses() {
        return ResponseEntity.ok(courseService.getAllCourses());
    }

    @PostMapping("/courses")
    public ResponseEntity<CourseDto> createCourse(@RequestBody CourseDto.Create req) {
        return ResponseEntity.ok(courseService.createCourse(req));
    }

    @PutMapping("/courses/{id}")
    public ResponseEntity<CourseDto> updateCourse(@PathVariable Long id, @RequestBody CourseDto.Create req) {
        return ResponseEntity.ok(courseService.updateCourse(id, req));
    }

    @DeleteMapping("/courses/{id}")
    public ResponseEntity<Void> deleteCourse(@PathVariable Long id) {
        courseService.deleteCourse(id);
        return ResponseEntity.noContent().build();
    }

    // Lectures
    @PostMapping("/lectures")
    public ResponseEntity<LectureDto> uploadLecture(@RequestBody LectureDto.Create req) {
        return ResponseEntity.ok(lectureService.createLecture(req));
    }

    @DeleteMapping("/lectures/{id}")
    public ResponseEntity<Void> deleteLecture(@PathVariable Long id) {
        lectureService.deleteLecture(id);
        return ResponseEntity.noContent().build();
    }

    // Enrollments
    @GetMapping("/enrollments")
    public ResponseEntity<List<EnrollmentDto>> getAllEnrollments() {
        return ResponseEntity.ok(enrollmentService.getAllEnrollments());
    }

    // Tickets
    @GetMapping("/tickets")
    public ResponseEntity<List<TicketDto>> getAllTickets() {
        return ResponseEntity.ok(ticketService.getAllTickets());
    }

    @PatchMapping("/tickets/{id}")
    public ResponseEntity<TicketDto> updateTicket(@PathVariable Long id, @RequestBody TicketDto.AdminUpdate req) {
        return ResponseEntity.ok(ticketService.adminUpdate(id, req));
    }
}
