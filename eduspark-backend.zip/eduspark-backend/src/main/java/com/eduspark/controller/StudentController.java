package com.eduspark.controller;

import com.eduspark.dto.*;
import com.eduspark.service.*;

import lombok.RequiredArgsConstructor;

import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/student")
@RequiredArgsConstructor
public class StudentController {

    private final EnrollmentService enrollmentService;
    private final LectureService lectureService;
    private final QuizService quizService;
    private final TicketService ticketService;
    private final NotificationService notificationService;
    private final AnalyticsService analyticsService;

    @PostMapping("/enroll")
    public ResponseEntity<EnrollmentDto> enroll(
            @RequestBody EnrollmentDto.Purchase req,
            Authentication auth
    ) {
        return ResponseEntity.ok(
                enrollmentService.purchaseCourse(
                        getUserId(auth),
                        req.getCourseId()
                )
        );
    }

    @GetMapping("/enrollments")
    public ResponseEntity<List<EnrollmentDto>> myEnrollments(
            Authentication auth
    ) {
        return ResponseEntity.ok(
                enrollmentService.getStudentEnrollments(
                        getUserId(auth)
                )
        );
    }

    @GetMapping("/courses/{courseId}/lectures")
    public ResponseEntity<List<LectureDto>> getLectures(
            @PathVariable Long courseId,
            Authentication auth
    ) {
        return ResponseEntity.ok(
                lectureService.getLecturesForCourse(
                        courseId,
                        getUserId(auth)
                )
        );
    }

    @PostMapping("/lectures/{lectureId}/complete")
    public ResponseEntity<LectureDto> completeLecture(
            @PathVariable Long lectureId,
            Authentication auth
    ) {
        return ResponseEntity.ok(
                lectureService.markComplete(
                        lectureId,
                        getUserId(auth)
                )
        );
    }

    @GetMapping("/lectures/{lectureId}/quizzes")
    public ResponseEntity<List<QuizDto>> getLectureQuizzes(
            @PathVariable Long lectureId
    ) {
        return ResponseEntity.ok(
                quizService.getQuizzesForLecture(
                        lectureId
                )
        );
    }

    // FINAL COURSE QUIZ API
    @GetMapping("/courses/{courseId}/quizzes")
    public ResponseEntity<List<QuizDto>> getCourseQuizzes(
            @PathVariable Long courseId
    ) {
        return ResponseEntity.ok(
                quizService.getCourseQuizzes(courseId)
        );
    }

    @PostMapping("/quizzes/submit")
    public ResponseEntity<QuizDto.Result> submitQuiz(
            @RequestBody QuizDto.Submit req,
            Authentication auth
    ) {
        return ResponseEntity.ok(
                quizService.submitAnswer(
                        getUserId(auth),
                        req
                )
        );
    }

    @GetMapping("/tickets")
    public ResponseEntity<List<TicketDto>> myTickets(
            Authentication auth
    ) {
        return ResponseEntity.ok(
                ticketService.getStudentTickets(
                        getUserId(auth)
                )
        );
    }

    @PostMapping("/tickets")
    public ResponseEntity<TicketDto> createTicket(
            @RequestBody TicketDto.Create req,
            Authentication auth
    ) {
        return ResponseEntity.ok(
                ticketService.createTicket(
                        getUserId(auth),
                        req
                )
        );
    }

    @GetMapping("/notifications")
    public ResponseEntity<List<NotificationDto>> notifications(
            Authentication auth
    ) {
        return ResponseEntity.ok(
                notificationService.getUserNotifications(
                        getUserId(auth)
                )
        );
    }


    @GetMapping("/progress")
    public ResponseEntity<AnalyticsDto> getProgress(
            Authentication auth
    ) {
        return ResponseEntity.ok(
                analyticsService.getStudentAnalytics(
                        getUserId(auth)
                )
        );
    }




    @PostMapping("/notifications/read-all")
    public ResponseEntity<Void> markAllRead(
            Authentication auth
    ) {
        notificationService.markAllRead(
                getUserId(auth)
        );

        return ResponseEntity.ok().build();
    }

    private Long getUserId(Authentication auth) {

        System.out.println("AUTH = " + auth);
        System.out.println("DETAILS = " + auth.getDetails());

        return (Long)
                ((UsernamePasswordAuthenticationToken) auth)
                        .getDetails();
    }
}