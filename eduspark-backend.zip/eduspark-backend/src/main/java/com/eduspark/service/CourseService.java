package com.eduspark.service;

import com.eduspark.dto.CourseDto;
import com.eduspark.dto.LectureDto;
import com.eduspark.entity.Course;
import com.eduspark.entity.Lecture;
import com.eduspark.repository.CourseRepository;
import com.eduspark.repository.EnrollmentRepository;
import com.eduspark.repository.LectureRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CourseService {

    private final CourseRepository courseRepository;
    private final EnrollmentRepository enrollmentRepository;
    private final LectureRepository lectureRepository;

    public List<CourseDto> getPublishedCourses() {
        return courseRepository.findByStatusOrderByCreatedAtDesc(Course.Status.PUBLISHED)
                .stream().map(c -> mapToDto(c, null, false)).collect(Collectors.toList());
    }

    public List<CourseDto> getAllCourses() {
        return courseRepository.findAll().stream()
                .map(c -> mapToDto(c, null, false)).collect(Collectors.toList());
    }

    public CourseDto getCourseById(Long id, Long studentId) {
        Course course = courseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Course not found"));
        boolean enrolled = studentId != null && enrollmentRepository.existsByStudentIdAndCourseId(studentId, id);
        return mapToDto(course, studentId, enrolled);
    }

    public CourseDto createCourse(CourseDto.Create req) {
        Course course = Course.builder()
                .title(req.getTitle())
                .description(req.getDescription())
                .price(req.getPrice())
                .thumbnailUrl(req.getThumbnailUrl())
                .category(req.getCategory())
                .instructor(req.getInstructor())
                .durationHours(req.getDurationHours())
                .status(req.getStatus() != null ? req.getStatus() : Course.Status.DRAFT)
                .build();
        return mapToDto(courseRepository.save(course), null, false);
    }

    public CourseDto updateCourse(Long id, CourseDto.Create req) {
        Course course = courseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Course not found"));
        if (req.getTitle() != null) course.setTitle(req.getTitle());
        if (req.getDescription() != null) course.setDescription(req.getDescription());
        if (req.getPrice() != null) course.setPrice(req.getPrice());
        if (req.getThumbnailUrl() != null) course.setThumbnailUrl(req.getThumbnailUrl());
        if (req.getCategory() != null) course.setCategory(req.getCategory());
        if (req.getInstructor() != null) course.setInstructor(req.getInstructor());
        if (req.getDurationHours() != null) course.setDurationHours(req.getDurationHours());
        if (req.getStatus() != null) course.setStatus(req.getStatus());
        return mapToDto(courseRepository.save(course), null, false);
    }

    public void deleteCourse(Long id) {
        courseRepository.deleteById(id);
    }

    private CourseDto mapToDto(Course c, Long studentId, boolean enrolled) {
        CourseDto dto = new CourseDto();
        dto.setId(c.getId());
        dto.setTitle(c.getTitle());
        dto.setDescription(c.getDescription());
        dto.setPrice(c.getPrice());
        dto.setThumbnailUrl(c.getThumbnailUrl());
        dto.setCategory(c.getCategory());
        dto.setInstructor(c.getInstructor());
        dto.setDurationHours(c.getDurationHours());
        dto.setStatus(c.getStatus());
        dto.setCreatedAt(c.getCreatedAt());
        dto.setEnrolled(enrolled);
        dto.setEnrolledCount(enrollmentRepository.countByCourseId(c.getId()));
        dto.setLectureCount(
                (int) lectureRepository.countByCourseId(c.getId())
        );
        return dto;
    }
}
