package com.eduspark.service;

import com.eduspark.dto.QuizDto;
import com.eduspark.entity.Lecture;
import com.eduspark.entity.Quiz;
import com.eduspark.entity.QuizAttempt;
import com.eduspark.entity.User;
import com.eduspark.repository.LectureRepository;
import com.eduspark.repository.QuizAttemptRepository;
import com.eduspark.repository.QuizRepository;
import com.eduspark.repository.UserRepository;

import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class QuizService {

    private final QuizRepository quizRepository;
    private final QuizAttemptRepository attemptRepository;
    private final LectureRepository lectureRepository;
    private final UserRepository userRepository;

    // -------------------------
    // Get quizzes for lecture
    // -------------------------
    public List<QuizDto> getQuizzesForLecture(Long lectureId) {

        return quizRepository.findByLectureId(lectureId)
                .stream()
                .map(this::convertToDto)
                .toList();
    }

    // -------------------------
    // Get quizzes for course
    // -------------------------
    public List<QuizDto> getCourseQuizzes(Long courseId) {

        List<Lecture> lectures =
                lectureRepository.findByCourseId(courseId);

        return lectures.stream()
                .flatMap(lecture ->
                        quizRepository.findByLectureId(
                                lecture.getId()
                        ).stream()
                )
                .map(this::convertToDto)
                .toList();
    }

    // -------------------------
    // Submit Answer
    // -------------------------
    public QuizDto.Result submitAnswer(
            Long studentId,
            QuizDto.Submit req
    ) {

        Quiz quiz =
                quizRepository.findById(req.getQuizId())
                        .orElseThrow(
                                () -> new RuntimeException("Quiz not found")
                        );

        boolean correct =
                quiz.getCorrectAnswer()
                        .equalsIgnoreCase(
                                req.getSelectedAnswer()
                        );

        User student = userRepository
                .findById(studentId)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Student not found: " + studentId
                        ));

        QuizAttempt attempt =
                QuizAttempt.builder()
                        .student(student)
                        .quiz(quiz)
                        .selectedAnswer(
                                req.getSelectedAnswer()
                        )
                        .correct(correct)
                        .build();

        attemptRepository.save(attempt);

        return QuizDto.Result.builder()
                .correct(correct)
                .build();
    }

    // -------------------------
    // DTO Mapper
    // -------------------------
    private QuizDto convertToDto(
            Quiz quiz
    ) {

        return QuizDto.builder()
                .id(quiz.getId())
                .question(quiz.getQuestion())
                .optionA(quiz.getOptionA())
                .optionB(quiz.getOptionB())
                .optionC(quiz.getOptionC())
                .optionD(quiz.getOptionD())
                .build();
    }
}