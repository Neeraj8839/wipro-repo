package com.eduspark.service;

import com.eduspark.dto.LectureDto;
import com.eduspark.entity.*;
import com.eduspark.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class LectureService {

    private final LectureRepository lectureRepository;
    private final CourseRepository courseRepository;
    private final LectureProgressRepository progressRepository;
    private final EnrollmentRepository enrollmentRepository;

    public List<LectureDto> getLecturesForCourse(Long courseId, Long studentId) {
        List<Lecture> lectures = lectureRepository.findByCourseIdOrderByOrderIndexAsc(courseId);
        boolean enrolled = studentId != null && enrollmentRepository.existsByStudentIdAndCourseId(studentId, courseId);

        return lectures.stream().map(l -> {
            LectureDto dto = mapToDto(l);
            if (studentId != null && enrolled) {
                boolean unlocked = isUnlocked(l, studentId, lectures);
                dto.setUnlocked(unlocked);
                progressRepository.findByStudentIdAndLectureId(studentId, l.getId())
                        .ifPresent(p -> dto.setCompleted(p.isCompleted()));
            } else {
                dto.setUnlocked(l.isFreePreview());
            }
            return dto;
        }).collect(Collectors.toList());
    }

    private boolean isUnlocked(Lecture lecture, Long studentId, List<Lecture> allLectures) {
        if (lecture.isFreePreview()) return true;
        int idx = lecture.getOrderIndex() != null ? lecture.getOrderIndex() : 0;
        if (idx <= 1) return true;
        // Must complete all previous lectures
        for (Lecture prev : allLectures) {
            int prevIdx = prev.getOrderIndex() != null ? prev.getOrderIndex() : 0;
            if (prevIdx < idx) {
                boolean completed = progressRepository
                        .findByStudentIdAndLectureId(studentId, prev.getId())
                        .map(LectureProgress::isCompleted).orElse(false);
                if (!completed) return false;
            }
        }
        return true;
    }

    public LectureDto markComplete(Long lectureId, Long studentId) {
        Lecture lecture = lectureRepository.findById(lectureId)
                .orElseThrow(() -> new RuntimeException("Lecture not found"));
        LectureProgress progress = progressRepository
                .findByStudentIdAndLectureId(studentId, lectureId)
                .orElse(LectureProgress.builder()
                        .student(User.builder().id(studentId).build())
                        .lecture(lecture)
                        .build());
        progress.setCompleted(true);
        progress.setCompletedAt(LocalDateTime.now());
        progressRepository.save(progress);

        // Update enrollment progress
        List<Lecture> allLectures = lectureRepository.findByCourseIdOrderByOrderIndexAsc(lecture.getCourse().getId());
        long completed = progressRepository.countCompletedByStudentAndCourse(studentId, lecture.getCourse().getId());
        int percent = (int) ((completed * 100) / allLectures.size());
        enrollmentRepository.findByStudentIdAndCourseId(studentId, lecture.getCourse().getId())
                .ifPresent(e -> { e.setProgressPercent(percent); enrollmentRepository.save(e); });

        return mapToDto(lecture);
    }

    public LectureDto createLecture(LectureDto.Create req) {
        Course course = courseRepository.findById(req.getCourseId())
                .orElseThrow(() -> new RuntimeException("Course not found"));
        Lecture lecture = Lecture.builder()
                .course(course)
                .title(req.getTitle())
                .description(req.getDescription())
                .videoUrl(req.getVideoUrl())
                .durationMinutes(req.getDurationMinutes())
                .orderIndex(req.getOrderIndex())
                .freePreview(req.isFreePreview())
                .type(req.getType())
                .build();
        return mapToDto(lectureRepository.save(lecture));
    }

    public void deleteLecture(Long id) {
        lectureRepository.deleteById(id);
    }

    private LectureDto mapToDto(Lecture l) {
        LectureDto dto = new LectureDto();
        dto.setId(l.getId());
        dto.setCourseId(l.getCourse() != null ? l.getCourse().getId() : null);
        dto.setTitle(l.getTitle());
        dto.setDescription(l.getDescription());
        dto.setVideoUrl(l.getVideoUrl());
        dto.setDurationMinutes(l.getDurationMinutes());
        dto.setOrderIndex(l.getOrderIndex());
        dto.setFreePreview(l.isFreePreview());
        dto.setType(l.getType());
        dto.setCreatedAt(l.getCreatedAt());
        return dto;
    }
}
