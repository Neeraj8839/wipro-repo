package com.eduspark.service;

import com.eduspark.dto.CertificateDto;
import com.eduspark.entity.Course;
import com.eduspark.entity.User;
import com.eduspark.repository.CourseRepository;
import com.eduspark.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
@RequiredArgsConstructor
public class CertificateService {

    private final UserRepository userRepository;
    private final CourseRepository courseRepository;

    public CertificateDto generateCertificate(
            Long studentId,
            Long courseId
    ) {

        User student =
                userRepository.findById(studentId)
                        .orElseThrow();

        Course course =
                courseRepository.findById(courseId)
                        .orElseThrow();

        CertificateDto dto =
                new CertificateDto();

        dto.setStudentName(
                student.getFirstName() + " " +
                        student.getLastName()
        );

        dto.setCourseTitle(
                course.getTitle()
        );

        dto.setCompletionDate(
                LocalDate.now().toString()
        );

        return dto;
    }
}