package com.eduspark.service;

import com.eduspark.dto.TicketDto;
import com.eduspark.entity.*;
import com.eduspark.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TicketService {

    private final SupportTicketRepository ticketRepository;
    private final UserRepository userRepository;
    private final NotificationRepository notificationRepository;

    public TicketDto createTicket(Long studentId, TicketDto.Create req) {
        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));
        SupportTicket ticket = SupportTicket.builder()
                .student(student)
                .subject(req.getSubject())
                .description(req.getDescription())
                .priority(req.getPriority() != null ? req.getPriority() : SupportTicket.Priority.MEDIUM)
                .status(SupportTicket.Status.OPEN)
                .build();
        return mapToDto(ticketRepository.save(ticket));
    }

    public List<TicketDto> getStudentTickets(Long studentId) {
        return ticketRepository.findByStudentIdOrderByCreatedAtDesc(studentId)
                .stream().map(this::mapToDto).collect(Collectors.toList());
    }

    public List<TicketDto> getAllTickets() {
        return ticketRepository.findAllByOrderByCreatedAtDesc()
                .stream().map(this::mapToDto).collect(Collectors.toList());
    }

    public TicketDto adminUpdate(Long ticketId, TicketDto.AdminUpdate req) {
        SupportTicket ticket = ticketRepository.findById(ticketId)
                .orElseThrow(() -> new RuntimeException("Ticket not found"));
        if (req.getStatus() != null) ticket.setStatus(req.getStatus());
        if (req.getAdminReply() != null) ticket.setAdminReply(req.getAdminReply());
        ticket = ticketRepository.save(ticket);

        if (req.getAdminReply() != null) {
            Notification n = Notification.builder()
                    .user(ticket.getStudent())
                    .title("Support Ticket Update")
                    .message("Admin replied to your ticket: " + ticket.getSubject())
                    .type(Notification.NotificationType.TICKET_UPDATE)
                    .build();
            notificationRepository.save(n);
        }
        return mapToDto(ticket);
    }

    private TicketDto mapToDto(SupportTicket t) {
        TicketDto dto = new TicketDto();
        dto.setId(t.getId());
        dto.setStudentId(t.getStudent().getId());
        dto.setStudentName(t.getStudent().getFirstName() + " " + t.getStudent().getLastName());
        dto.setStudentEmail(t.getStudent().getEmail());
        dto.setSubject(t.getSubject());
        dto.setDescription(t.getDescription());
        dto.setStatus(t.getStatus());
        dto.setPriority(t.getPriority());
        dto.setAdminReply(t.getAdminReply());
        dto.setCreatedAt(t.getCreatedAt());
        dto.setUpdatedAt(t.getUpdatedAt());
        return dto;
    }
}
