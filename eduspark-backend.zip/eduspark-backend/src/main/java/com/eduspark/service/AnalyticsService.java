package com.eduspark.service;

import com.eduspark.dto.AnalyticsDto;
import com.eduspark.entity.Enrollment;
import com.eduspark.entity.Lecture;
import com.eduspark.repository.*;

import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;

import java.util.List;
import com.eduspark.dto.DailyProgressDto;
import com.eduspark.entity.LectureProgress;

import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class AnalyticsService {

    private final EnrollmentRepository enrollmentRepository;
    private final LectureProgressRepository progressRepository;
    private final QuizAttemptRepository quizAttemptRepository;
    private final LectureRepository lectureRepository;
    private final QuizRepository quizRepository;

    public AnalyticsDto getStudentAnalytics(
            Long studentId
    ) {

        AnalyticsDto dto =
                new AnalyticsDto();

        // --------------------------
        // Enrollments
        // --------------------------

        List<Enrollment> enrollments =
                enrollmentRepository.findByStudentId(
                        studentId
                );

        long enrolledCourses =
                enrollments.size();

        long completedCourses =
                enrollments.stream()
                        .filter(
                                enrollment ->
                                        enrollment.getProgressPercent() != null
                                                &&
                                                enrollment.getProgressPercent() == 100
                        )
                        .count();

        // --------------------------
        // Lectures
        // --------------------------

        long completedLectures =
                progressRepository
                        .findByStudentIdAndCompleted(
                                studentId,
                                true
                        )
                        .size();

        long totalLectures = 0;

        for (Enrollment enrollment : enrollments) {

            totalLectures +=
                    lectureRepository.countByCourseId(
                            enrollment.getCourse()
                                    .getId()
                    );
        }

        long pendingLectures =
                Math.max(
                        0,
                        totalLectures - completedLectures
                );

        // --------------------------
        // Quizzes
        // --------------------------

        long totalQuizzes = 0;

        for (Enrollment enrollment : enrollments) {

            totalQuizzes +=
                    quizRepository
                            .findByLecture_Course_Id(
                                    enrollment.getCourse()
                                            .getId()
                            )
                            .size();
        }

        long completedQuizzes =
                quizAttemptRepository
                        .findByStudentId(studentId)
                        .size();

        long pendingQuizzes =
                Math.max(
                        0,
                        totalQuizzes - completedQuizzes
                );

        // --------------------------
        // Quiz Performance
        // --------------------------

        long correctAnswers =
                quizAttemptRepository
                        .countCorrectByStudent(
                                studentId
                        );

        long totalAttempts =
                quizAttemptRepository
                        .findByStudentId(studentId)
                        .size();

        double performance = 0;

        if (totalAttempts > 0) {

            performance =
                    ((double) correctAnswers
                            / totalAttempts)
                            * 100;
        }

        // --------------------------
        // Attendance
        // --------------------------

        double attendance = 0;

        if (totalLectures > 0) {

            attendance =
                    ((double) completedLectures
                            / totalLectures)
                            * 100;
        }

        // --------------------------
        // Certificates
        // --------------------------

        long certificatesEarned =
                completedCourses;

        // --------------------------
        // DTO Mapping
        // --------------------------

        dto.setCompletedLectures(
                completedLectures
        );

        dto.setPendingLectures(
                pendingLectures
        );

        dto.setCompletedQuizzes(
                completedQuizzes
        );

        dto.setPendingQuizzes(
                pendingQuizzes
        );

        dto.setCertificatesEarned(
                certificatesEarned
        );

        dto.setAttendancePercentage(
                attendance
        );

        dto.setOverallPerformance(
                performance
        );

        dto.setEnrolledCourses(
                enrolledCourses
        );

        dto.setCompletedCourses(
                completedCourses
        );

        dto.setTotalQuizAttempts(
                totalAttempts
        );

        dto.setCorrectQuizAnswers(
                correctAnswers
        );


        // --------------------------
// Daily Activity Analytics
// --------------------------

        Map<String, DailyProgressDto> activityMap =
                new HashMap<>();

        List<LectureProgress> progressList =
                progressRepository.findRecentProgress(
                        studentId
                );

        for (LectureProgress progress : progressList) {

            if (progress.getCompletedAt() == null) {
                continue;
            }

            DayOfWeek day =
                    progress.getCompletedAt()
                            .getDayOfWeek();

            String dayName =
                    day.name()
                            .substring(0, 3);

            DailyProgressDto daily =
                    activityMap.getOrDefault(
                            dayName,
                            new DailyProgressDto()
                    );

            daily.setDay(dayName);

            daily.setLecturesWatched(
                    daily.getLecturesWatched() + 1
            );

            activityMap.put(
                    dayName,
                    daily
            );
        }

        dto.setActivity(
                new ArrayList<>(
                        activityMap.values()
                )
        );




        return dto;
    }
}