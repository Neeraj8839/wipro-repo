package com.eduspark.service;

import com.eduspark.dto.EnrollmentDto;
import com.eduspark.entity.*;
import com.eduspark.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class EnrollmentService {

    private final EnrollmentRepository enrollmentRepository;
    private final UserRepository userRepository;
    private final CourseRepository courseRepository;
    private final NotificationRepository notificationRepository;



    public EnrollmentDto purchaseCourse(Long studentId, Long courseId) {
        if (enrollmentRepository.existsByStudentIdAndCourseId(studentId, courseId)) {
            throw new RuntimeException("Already enrolled in this course");
        }
        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));
        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));

        Enrollment enrollment = Enrollment.builder()
                .student(student)
                .course(course)
                .amountPaid(course.getPrice())
                .paymentStatus(Enrollment.PaymentStatus.COMPLETED)
                .transactionId("TXN-" + System.currentTimeMillis())
                .build();
        enrollment = enrollmentRepository.save(enrollment);

        Notification notification = Notification.builder()
                .user(student)
                .title("Enrollment Successful!")
                .message("You are now enrolled in " + course.getTitle() + ". Start learning!")
                .type(Notification.NotificationType.ENROLLMENT)
                .build();
        notificationRepository.save(notification);

        return mapToDto(enrollment);
    }

    public List<EnrollmentDto> getStudentEnrollments(Long studentId) {
        return enrollmentRepository.findByStudentId(studentId)
                .stream().map(this::mapToDto).collect(Collectors.toList());
    }

    public List<EnrollmentDto> getCourseEnrollments(Long courseId) {
        return enrollmentRepository.findByCourseId(courseId)
                .stream().map(this::mapToDto).collect(Collectors.toList());
    }

    public List<EnrollmentDto> getAllEnrollments() {
        return enrollmentRepository.findAll()
                .stream().map(this::mapToDto).collect(Collectors.toList());
    }

    private EnrollmentDto mapToDto(Enrollment e) {
        EnrollmentDto dto = new EnrollmentDto();
        dto.setId(e.getId());
        dto.setStudentId(e.getStudent().getId());
        dto.setStudentName(e.getStudent().getFirstName() + " " + e.getStudent().getLastName());
        dto.setStudentEmail(e.getStudent().getEmail());
        dto.setCourseId(e.getCourse().getId());
        dto.setCourseTitle(e.getCourse().getTitle());
        dto.setAmountPaid(e.getAmountPaid());
        dto.setPaymentStatus(e.getPaymentStatus());
        dto.setProgressPercent(e.getProgressPercent());
        dto.setEnrolledAt(e.getEnrolledAt());
        return dto;
    }
}
