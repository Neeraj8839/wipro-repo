package com.eduspark.service;

import com.eduspark.dto.*;
import com.eduspark.entity.*;
import com.eduspark.repository.*;
import org.springframework.security.crypto.password.PasswordEncoder;

import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AdminService {

    private final UserRepository userRepository;
    private final EnrollmentRepository enrollmentRepository;
    private final SupportTicketRepository ticketRepository;
    private final CourseRepository courseRepository;
    private final QuizAttemptRepository quizAttemptRepository;
    private final LectureProgressRepository progressRepository;
    private final NotificationRepository notificationRepository;
    private final PasswordEncoder passwordEncoder;

    public AdminDashboardDto getDashboard() {

        AdminDashboardDto dto = new AdminDashboardDto();

        dto.setTotalStudents(
                userRepository.countByRole(User.Role.STUDENT)
        );

        dto.setTotalCourses(
                courseRepository.count()
        );

        dto.setTotalEnrollments(
                enrollmentRepository.count()
        );

        dto.setOpenTickets(
                ticketRepository.countByStatus(
                        SupportTicket.Status.OPEN
                )
        );

        return dto;
    }



    // ADD HERE 👇👇👇

    public AdminAnalyticsDto getAnalytics() {

        AdminAnalyticsDto dto =
                new AdminAnalyticsDto();

        dto.setTotalStudents(
                userRepository.countByRole(User.Role.STUDENT)
        );

        dto.setTotalCourses(
                courseRepository.count()
        );

        dto.setTotalEnrollments(
                enrollmentRepository.count()
        );

        dto.setOpenTickets(
                ticketRepository.countByStatus(
                        SupportTicket.Status.OPEN
                )
        );

        return dto;
    }





    public List<StudentProfileDto> getAllStudents() {

        return userRepository.findByRole(User.Role.STUDENT)
                .stream()
                .map(this::mapStudentToDto)
                .collect(Collectors.toList());
    }

    public StudentProfileDto getStudentProfile(Long studentId) {

        User student = userRepository.findById(studentId)
                .orElseThrow(
                        () -> new RuntimeException("Student not found")
                );

        return mapStudentToDto(student);
    }

    @Transactional
    public void deleteStudent(Long studentId) {

        if (!userRepository.existsById(studentId)) {
            throw new RuntimeException("Student not found");
        }

        // Delete child records first

        notificationRepository.deleteByUserId(studentId);

        quizAttemptRepository.deleteByStudentId(studentId);

        progressRepository.deleteByStudentId(studentId);

        ticketRepository.deleteByStudentId(studentId);

        enrollmentRepository.deleteByStudentId(studentId);


        // Finally delete student

        userRepository.deleteById(studentId);
    }



    public StudentProfileDto updateStudentStatus(
            Long studentId,
            boolean active
    ) {

        User student = userRepository.findById(studentId)
                .orElseThrow(
                        () -> new RuntimeException("Student not found")
                );

        student.setActive(active);

        return mapStudentToDto(
                userRepository.save(student)
        );
    }


// ADD HERE 👇👇👇

    public StudentProfileDto createStudent(
            CreateStudentRequest req
    ) {

        if (userRepository.existsByEmail(req.getEmail())) {

            throw new RuntimeException(
                    "Email already exists"
            );
        }

        User student = User.builder()
                .firstName(req.getFirstName())
                .lastName(req.getLastName())
                .email(req.getEmail())
                .password(
                        passwordEncoder.encode(
                                req.getPassword()
                        )
                )
                .phone(req.getPhone())
                .role(User.Role.STUDENT)
                .active(true)
                .build();

        User saved =
                userRepository.save(student);

        return mapStudentToDto(saved);
    }


    public StudentProfileDto updateStudent(
            Long id,
            UpdateStudentRequest req
    ) {

        User student =
                userRepository.findById(id)
                        .orElseThrow(
                                () -> new RuntimeException(
                                        "Student not found"
                                ));

        student.setFirstName(
                req.getFirstName()
        );

        student.setLastName(
                req.getLastName()
        );

        student.setEmail(
                req.getEmail()
        );

        student.setPhone(
                req.getPhone()
        );

        User updated =
                userRepository.save(student);

        return mapStudentToDto(updated);
    }


    // Existing method





    private StudentProfileDto mapStudentToDto(User u) {

        StudentProfileDto dto =
                new StudentProfileDto();

        dto.setId(u.getId());
        dto.setFirstName(u.getFirstName());
        dto.setLastName(u.getLastName());
        dto.setEmail(u.getEmail());
        dto.setPhone(u.getPhone());
        dto.setAvatarUrl(u.getAvatarUrl());
        dto.setActive(u.isActive());
        dto.setCreatedAt(u.getCreatedAt());

        dto.setEnrolledCourses(
                enrollmentRepository
                        .findByStudentId(u.getId())
                        .size()
        );

        dto.setCorrectQuizAnswers(
                (int) quizAttemptRepository
                        .countCorrectByStudent(u.getId())
        );

        dto.setCompletedLectures(
                progressRepository
                        .findByStudentIdAndCompleted(
                                u.getId(),
                                true
                        )
                        .size()
        );

        return dto;
    }
}