package com.eduspark.dto;

import com.eduspark.entity.SupportTicket;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class TicketDto {
    private Long id;
    private Long studentId;
    private String studentName;
    private String studentEmail;
    private String subject;
    private String description;
    private SupportTicket.Status status;
    private SupportTicket.Priority priority;
    private String adminReply;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @Data
    public static class Create {
        private String subject;
        private String description;
        private SupportTicket.Priority priority;
    }

    @Data
    public static class AdminUpdate {
        private SupportTicket.Status status;
        private String adminReply;
    }
}
