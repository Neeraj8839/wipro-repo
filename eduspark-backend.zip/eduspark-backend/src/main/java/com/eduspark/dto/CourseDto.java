package com.eduspark.dto;

import com.eduspark.entity.Course;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class CourseDto {
    private Long id;
    private String title;
    private String description;
    private BigDecimal price;
    private String thumbnailUrl;
    private String category;
    private String instructor;
    private Integer durationHours;
    private Course.Status status;
    private int enrolledCount;
    private int lectureCount;
    private boolean enrolled;
    private LocalDateTime createdAt;
    private List<LectureDto> lectures;

    @Data
    public static class Create {
        private String title;
        private String description;
        private BigDecimal price;
        private String thumbnailUrl;
        private String category;
        private String instructor;
        private Integer durationHours;
        private Course.Status status;
    }
}
