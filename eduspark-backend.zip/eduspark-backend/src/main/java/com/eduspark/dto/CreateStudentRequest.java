package com.eduspark.dto;

import lombok.Data;

@Data
public class CreateStudentRequest {

    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private String phone;
}