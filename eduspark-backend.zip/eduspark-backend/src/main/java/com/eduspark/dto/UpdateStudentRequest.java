package com.eduspark.dto;

import lombok.Data;

@Data
public class UpdateStudentRequest {

    private String firstName;
    private String lastName;
    private String email;
    private String phone;
}