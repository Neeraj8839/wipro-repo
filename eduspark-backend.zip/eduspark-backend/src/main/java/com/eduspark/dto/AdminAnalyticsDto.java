package com.eduspark.dto;

import lombok.Data;

@Data
public class AdminAnalyticsDto {

    private long totalStudents;

    private long activeStudents;

    private long totalCourses;

    private long totalEnrollments;

    private long certificatesIssued;

    private long openTickets;

    private long resolvedTickets;

    private double totalRevenue;
}