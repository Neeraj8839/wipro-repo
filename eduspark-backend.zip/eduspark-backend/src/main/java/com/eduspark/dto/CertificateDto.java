package com.eduspark.dto;

import lombok.Data;

@Data
public class CertificateDto {

    private String studentName;
    private String courseTitle;
    private String completionDate;
}