package com.eduspark.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QuizDto {

    private Long id;

    private String question;

    private String optionA;

    private String optionB;

    private String optionC;

    private String optionD;

    @Data
    public static class Submit {

        private Long quizId;

        private String selectedAnswer;
    }

    @Builder
    @Data
    public static class Result {

        private boolean correct;
    }
}