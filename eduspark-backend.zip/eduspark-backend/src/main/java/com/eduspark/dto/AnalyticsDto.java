package com.eduspark.dto;

import lombok.Data;
import java.util.List;

@Data
public class AnalyticsDto {

    private long completedLectures;

    private long pendingLectures;

    private long completedQuizzes;

    private long pendingQuizzes;

    private long certificatesEarned;

    private double attendancePercentage;

    private double overallPerformance;

    private long enrolledCourses;

    private long completedCourses;

    private long totalQuizAttempts;

    private long correctQuizAnswers;

    private List<DailyProgressDto> activity;
}