package com.eduspark.dto;

import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class StudentProfileDto {
    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String phone;
    private String avatarUrl;
    private boolean active;
    private LocalDateTime createdAt;
    private int enrolledCourses;
    private int completedLectures;
    private int correctQuizAnswers;
    private List<EnrollmentDto> enrollments;
}
