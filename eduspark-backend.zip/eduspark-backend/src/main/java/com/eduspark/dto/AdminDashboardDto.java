package com.eduspark.dto;

import lombok.Data;
import java.util.List;

@Data
public class AdminDashboardDto {
    private long totalStudents;
    private long totalCourses;
    private long totalEnrollments;
    private long openTickets;
    private List<EnrollmentDto> recentEnrollments;
    private List<TicketDto> recentTickets;
}
