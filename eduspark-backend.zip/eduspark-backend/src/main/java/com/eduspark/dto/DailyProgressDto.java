package com.eduspark.dto;

import lombok.Data;

@Data
public class DailyProgressDto {

    private String day;

    private long lecturesWatched;

    private long quizzesAttempted;
}