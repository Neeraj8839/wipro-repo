package com.eduspark.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

public class AuthRequest {

    @Data
    public static class Register {
        @NotBlank private String firstName;
        @NotBlank private String lastName;
        @Email @NotBlank private String email;
        @Size(min = 6) @NotBlank private String password;
        private String phone;
    }

    @Data
    public static class Login {
        @Email @NotBlank private String email;
        @NotBlank private String password;
    }
}
