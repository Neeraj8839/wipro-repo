package com.eduspark.dto;

import com.eduspark.entity.Notification;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class NotificationDto {
    private Long id;
    private String title;
    private String message;
    private boolean read;
    private Notification.NotificationType type;
    private LocalDateTime createdAt;
}
