package com.eduspark.dto;

import com.eduspark.entity.Enrollment;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class EnrollmentDto {
    private Long id;
    private Long studentId;
    private String studentName;
    private String studentEmail;
    private Long courseId;
    private String courseTitle;
    private BigDecimal amountPaid;
    private Enrollment.PaymentStatus paymentStatus;
    private Integer progressPercent;
    private LocalDateTime enrolledAt;

    @Data
    public static class Purchase {
        private Long courseId;
    }
}
