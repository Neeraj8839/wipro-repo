package com.eduspark.dto;

import com.eduspark.entity.Lecture;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class LectureDto {
    private Long id;
    private Long courseId;
    private String title;
    private String description;
    private String videoUrl;
    private Integer durationMinutes;
    private Integer orderIndex;
    private boolean freePreview;
    private Lecture.LectureType type;
    private boolean unlocked;
    private boolean completed;
    private LocalDateTime createdAt;
    private List<QuizDto> quizzes;

    @Data
    public static class Create {
        private Long courseId;
        private String title;
        private String description;
        private String videoUrl;
        private Integer durationMinutes;
        private Integer orderIndex;
        private boolean freePreview;
        private Lecture.LectureType type;
    }
}
