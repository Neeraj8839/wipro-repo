package com.eduspark;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EdusparkBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EdusparkBackendApplication.class, args);
	}

}
