package com.eduspark;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdusparkBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
