import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './context/AuthContext';
import { ProtectedRoute } from './components/common/ProtectedRoute';
import Navbar from './components/common/Navbar';
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import AskQuestionPage from './pages/AskQuestionPage';
import QuestionDetailPage from './pages/QuestionDetailPage';
import ChatRoomPage from './pages/ChatRoomPage';
import DashboardPage from './pages/DashboardPage';
import AdminPage from './pages/AdminPage';
import SearchPage from './pages/SearchPage';
import ProfilePage from './pages/ProfilePage';

function Layout({ children }) {
  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Navbar />
      <main style={{ flex: 1 }}>{children}</main>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: 'var(--bg3)',
              color: 'var(--text)',
              border: '1px solid var(--border)',
              fontFamily: 'var(--font)',
              fontSize: '13px',
            },
            success: { iconTheme: { primary: 'var(--green)', secondary: 'var(--bg3)' } },
            error: { iconTheme: { primary: 'var(--red)', secondary: 'var(--bg3)' } },
          }}
        />
        <Routes>
          {/* Public */}
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />

          {/* Main layout */}
          <Route path="/" element={<Layout><HomePage /></Layout>} />
          <Route path="/questions" element={<Layout><HomePage /></Layout>} />
          <Route path="/questions/:id" element={<Layout><QuestionDetailPage /></Layout>} />
          <Route path="/search" element={<Layout><SearchPage /></Layout>} />
          <Route path="/chat" element={<Layout><ChatRoomPage /></Layout>} />
          <Route path="/chat/:roomId" element={<Layout><ChatRoomPage /></Layout>} />

          {/* Protected */}
          <Route path="/ask" element={
            <Layout>
              <ProtectedRoute><AskQuestionPage /></ProtectedRoute>
            </Layout>
          } />
          <Route path="/profile" element={
            <Layout>
              <ProtectedRoute><ProfilePage /></ProtectedRoute>
            </Layout>
          } />
          <Route path="/dashboard" element={
            <Layout>
              <ProtectedRoute requireModerator><DashboardPage /></ProtectedRoute>
            </Layout>
          } />
          <Route path="/admin" element={
            <Layout>
              <ProtectedRoute requireAdmin><AdminPage /></ProtectedRoute>
            </Layout>
          } />

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
