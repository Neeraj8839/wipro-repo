import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' },
});

// Attach JWT to every request
api.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Handle 401 globally
api.interceptors.response.use(
  res => res,
  err => {
    if (err.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

// ── Auth ─────────────────────────────────────────────
export const authApi = {
  register: data => api.post('/auth/register', data),
  login: data => api.post('/auth/login', data),
};

// ── Questions ─────────────────────────────────────────
export const questionsApi = {
  getAll: (page = 0, size = 10, sort = 'latest') =>
    api.get(`/questions?page=${page}&size=${size}&sort=${sort}`),
  getById: id => api.get(`/questions/${id}`),
  search: (q, page = 0) => api.get(`/questions/search?q=${q}&page=${page}`),
  create: data => api.post('/questions', data),
  vote: (id, delta) => api.post(`/questions/${id}/vote?delta=${delta}`),
  delete: id => api.delete(`/questions/${id}`),
  getSimilar: id => api.get(`/questions/${id}/similar`),
  getTrendingTags: () => api.get('/questions/trending-tags'),
};

// ── Answers ─────────────────────────────────────────
export const answersApi = {
  getByQuestion: qId => api.get(`/questions/${qId}/answers`),
  create: (qId, data) => api.post(`/questions/${qId}/answers`, data),
  generateAi: qId => api.post(`/questions/${qId}/answers/ai`),
  accept: id => api.post(`/answers/${id}/accept`),
  vote: (id, delta) => api.post(`/answers/${id}/vote?delta=${delta}`),
  summarize: id => api.get(`/answers/${id}/summarize`),
  enhanceGrammar: text => api.post('/ai/enhance-grammar', { text }),
};

// ── Chat ─────────────────────────────────────────────
export const chatApi = {
  getHistory: (roomId, limit = 50) => api.get(`/chat/${roomId}/history?limit=${limit}`),
  getRooms: () => api.get('/chat/rooms'),
};

// ── Analytics / Admin ─────────────────────────────────
export const analyticsApi = {
  getDashboard: () => api.get('/analytics/dashboard'),
  getFlagged: () => api.get('/moderation/flagged'),
  approveQuestion: id => api.post(`/moderation/questions/${id}/approve`),
  removeQuestion: id => api.post(`/moderation/questions/${id}/remove`),
  moderateContent: content => api.post('/ai/moderate', { content }),
};

export default api;
