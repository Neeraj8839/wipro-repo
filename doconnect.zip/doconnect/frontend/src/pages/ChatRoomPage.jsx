import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { chatApi } from '../api';
import { useAuth } from '../context/AuthContext';
import { useWebSocket } from '../hooks/useWebSocket';
import { Send, Hash, Zap, Circle, Users, ArrowLeft } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import toast from 'react-hot-toast';

const ROOM_COLORS = {
  general: 'var(--accent)', java: 'var(--yellow)', python: 'var(--green)',
  javascript: 'var(--yellow)', 'spring-boot': 'var(--green)', react: 'var(--teal)',
  database: 'var(--accent)', devops: 'var(--red)', 'ai-ml': 'var(--accent2)', help: 'var(--teal)',
};

function MessageBubble({ msg, currentUser }) {
  const isOwn = msg.senderName === currentUser?.displayName ||
    msg.senderName === currentUser?.username;
  const isSystem = msg.type === 'SYSTEM' || msg.type === 'JOIN' || msg.type === 'LEAVE';
  const isAI = msg.type === 'AI';

  if (isSystem) return (
    <div style={{ textAlign: 'center', margin: '8px 0' }}>
      <span style={{
        fontSize: 12, color: 'var(--text3)', background: 'var(--bg3)',
        padding: '3px 10px', borderRadius: 10,
      }}>
        {msg.content}
      </span>
    </div>
  );

  return (
    <div className="fade-in" style={{
      display: 'flex',
      flexDirection: isOwn ? 'row-reverse' : 'row',
      gap: 8, marginBottom: 12, alignItems: 'flex-end',
    }}>
      {/* Avatar */}
      <div style={{
        width: 28, height: 28, borderRadius: '50%', flexShrink: 0,
        background: isAI
          ? 'linear-gradient(135deg, var(--accent), var(--teal))'
          : isOwn ? 'var(--accent)' : 'var(--bg4)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 11, fontWeight: 700, color: 'white',
      }}>
        {isAI ? <Zap size={12} /> : msg.senderName?.[0]?.toUpperCase() || '?'}
      </div>

      <div style={{ maxWidth: '72%', minWidth: 0 }}>
        {!isOwn && (
          <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 3, marginLeft: 2 }}>
            {isAI ? <span className="ai-badge"><Zap size={9} /> DoConnect AI</span> : msg.senderName}
          </div>
        )}
        <div style={{
          padding: '9px 13px', borderRadius: isOwn ? '12px 4px 12px 12px' : '4px 12px 12px 12px',
          background: isAI
            ? 'linear-gradient(135deg, rgba(108,99,255,0.15), rgba(20,184,166,0.15))'
            : isOwn ? 'var(--accent)' : 'var(--bg3)',
          border: isAI ? '1px solid rgba(108,99,255,0.2)' : isOwn ? 'none' : '1px solid var(--border)',
          fontSize: 14, color: 'var(--text)', lineHeight: 1.5,
          wordBreak: 'break-word',
        }}>
          {msg.content}
        </div>
        <div style={{
          fontSize: 10, color: 'var(--text3)', marginTop: 3,
          textAlign: isOwn ? 'right' : 'left', marginLeft: 4, marginRight: 4,
        }}>
          {msg.createdAt && formatDistanceToNow(new Date(msg.createdAt), { addSuffix: true })}
        </div>
      </div>
    </div>
  );
}

export default function ChatRoomPage() {
  const { roomId = 'general' } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [messages, setMessages] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(true);
  const [onlineCount] = useState(Math.floor(Math.random() * 20) + 3);
  const bottomRef = useRef(null);

  const handleIncoming = msg => {
    setMessages(prev => [...prev, { ...msg, createdAt: msg.createdAt || new Date().toISOString() }]);
  };

  const { connected, sendMessage } = useWebSocket(roomId, handleIncoming);

  useEffect(() => {
    loadHistory();
    loadRooms();
  }, [roomId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const loadHistory = async () => {
    setLoading(true);
    setMessages([]);
    try {
      const res = await chatApi.getHistory(roomId, 50);
      setMessages(res.data);
    } catch {
      // Room might be empty
    } finally {
      setLoading(false);
    }
  };

  const loadRooms = async () => {
    try {
      const res = await chatApi.getRooms();
      setRooms(res.data);
    } catch {}
  };

  const handleSend = e => {
    e.preventDefault();
    if (!input.trim()) return;
    if (!user) { toast.error('Login to chat'); return; }
    if (!connected) { toast.error('Connecting to chat...'); return; }

    const username = user.displayName || user.username;
    sendMessage(input.trim(), username, 'CHAT');

    // Optimistic update
    setMessages(prev => [...prev, {
      id: Date.now(),
      content: input.trim(),
      senderName: username,
      type: 'CHAT',
      createdAt: new Date().toISOString(),
    }]);
    setInput('');
  };

  const handleJoinNotify = () => {
    if (!connected || !user) return;
    const username = user.displayName || user.username;
    sendMessage(`${username} joined the room`, username, 'JOIN');
  };

  useEffect(() => {
    if (connected && user) handleJoinNotify();
  }, [connected, roomId]);

  return (
    <div style={{ height: 'calc(100vh - 60px)', display: 'flex' }}>
      {/* Rooms sidebar */}
      <div style={{
        width: 220, background: 'var(--bg2)', borderRight: '1px solid var(--border)',
        display: 'flex', flexDirection: 'column', flexShrink: 0,
      }}>
        <div style={{ padding: '16px 14px', borderBottom: '1px solid var(--border)' }}>
          <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
            Chat Rooms
          </span>
        </div>
        <div style={{ flex: 1, overflowY: 'auto', padding: '8px' }}>
          {rooms.map(room => (
            <Link
              key={room}
              to={`/chat/${room}`}
              style={{
                display: 'flex', alignItems: 'center', gap: 8,
                padding: '8px 10px', borderRadius: 8, marginBottom: 2,
                background: room === roomId ? 'var(--accent-bg)' : 'transparent',
                color: room === roomId ? 'var(--accent2)' : 'var(--text2)',
                fontSize: 14, fontWeight: room === roomId ? 500 : 400,
                transition: 'all 0.1s',
              }}
            >
              <Hash size={14} style={{ color: ROOM_COLORS[room] || 'var(--text3)', flexShrink: 0 }} />
              {room}
            </Link>
          ))}
        </div>

        {/* User status */}
        {user ? (
          <div style={{
            padding: '12px 14px', borderTop: '1px solid var(--border)',
            display: 'flex', alignItems: 'center', gap: 8,
          }}>
            <div style={{
              width: 28, height: 28, borderRadius: '50%',
              background: 'var(--accent)', display: 'flex', alignItems: 'center',
              justifyContent: 'center', fontSize: 11, fontWeight: 700, color: 'white',
            }}>
              {(user.displayName || user.username)[0].toUpperCase()}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {user.displayName || user.username}
              </div>
              <div style={{ fontSize: 11, color: 'var(--green)', display: 'flex', alignItems: 'center', gap: 3 }}>
                <Circle size={6} fill="var(--green)" /> Online
              </div>
            </div>
          </div>
        ) : (
          <div style={{ padding: '12px 14px', borderTop: '1px solid var(--border)' }}>
            <Link to="/login" className="btn btn-primary btn-sm" style={{ width: '100%', justifyContent: 'center' }}>
              Login to Chat
            </Link>
          </div>
        )}
      </div>

      {/* Chat area */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        {/* Header */}
        <div style={{
          padding: '0 20px', height: 52,
          background: 'var(--bg2)', borderBottom: '1px solid var(--border)',
          display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <Hash size={16} style={{ color: ROOM_COLORS[roomId] || 'var(--accent)' }} />
          <span style={{ fontWeight: 600, color: 'var(--text)', fontSize: 15 }}>{roomId}</span>
          <span style={{ fontSize: 12, color: 'var(--text3)' }}>Real-time discussion</span>
          <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 6 }}>
            <Users size={13} style={{ color: 'var(--text3)' }} />
            <span style={{ fontSize: 12, color: 'var(--text3)' }}>{onlineCount} online</span>
            <div style={{
              width: 8, height: 8, borderRadius: '50%',
              background: connected ? 'var(--green)' : 'var(--red)',
              marginLeft: 4,
            }} title={connected ? 'Connected' : 'Connecting...'} />
          </div>
        </div>

        {/* Messages */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '20px 24px' }}>
          {loading ? (
            <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 40 }}>
              <div className="spinner" style={{ width: 28, height: 28 }} />
            </div>
          ) : messages.length === 0 ? (
            <div style={{ textAlign: 'center', color: 'var(--text3)', paddingTop: 60 }}>
              <Hash size={40} style={{ opacity: 0.2, marginBottom: 10 }} />
              <p style={{ fontSize: 14 }}>No messages yet. Start the conversation!</p>
            </div>
          ) : (
            messages.map((msg, i) => (
              <MessageBubble key={msg.id || i} msg={msg} currentUser={user} />
            ))
          )}
          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div style={{
          padding: '12px 20px', background: 'var(--bg2)', borderTop: '1px solid var(--border)',
        }}>
          <form onSubmit={handleSend} style={{ display: 'flex', gap: 8 }}>
            <input
              value={input}
              onChange={e => setInput(e.target.value)}
              placeholder={user ? `Message #${roomId}...` : 'Login to send messages'}
              disabled={!user}
              style={{ flex: 1, height: 40 }}
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) handleSend(e); }}
            />
            <button
              type="submit"
              className="btn btn-primary btn-icon"
              disabled={!user || !connected || !input.trim()}
              style={{ width: 40, height: 40, borderRadius: 10, justifyContent: 'center' }}
            >
              <Send size={16} />
            </button>
          </form>
          {!connected && user && (
            <p style={{ fontSize: 11, color: 'var(--yellow)', marginTop: 4 }}>
              Connecting to WebSocket...
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
