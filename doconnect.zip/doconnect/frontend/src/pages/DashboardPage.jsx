import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { analyticsApi, questionsApi } from '../api';
import { useAuth } from '../context/AuthContext';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend,
} from 'recharts';
import {
  MessageSquare, Users, FileText, TrendingUp, Flag,
  CheckCircle, Zap, BarChart2, Shield,
} from 'lucide-react';
import toast from 'react-hot-toast';

const COLORS = ['#6c63ff', '#14b8a6', '#f59e0b', '#ef4444', '#22c55e', '#8b83ff'];

function StatCard({ icon: Icon, label, value, color, sub }) {
  return (
    <div className="card" style={{
      display: 'flex', alignItems: 'center', gap: 16, padding: '18px 20px',
    }}>
      <div style={{
        width: 44, height: 44, borderRadius: 10, flexShrink: 0,
        background: `${color}22`, display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <Icon size={20} color={color} />
      </div>
      <div>
        <div style={{ fontSize: 22, fontWeight: 700, color: 'var(--text)', lineHeight: 1 }}>
          {value ?? <span className="spinner" style={{ width: 18, height: 18 }} />}
        </div>
        <div style={{ fontSize: 13, color: 'var(--text2)', marginTop: 3 }}>{label}</div>
        {sub && <div style={{ fontSize: 11, color: color, marginTop: 2 }}>{sub}</div>}
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const { user, isModerator } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isModerator) { navigate('/'); return; }
    loadStats();
  }, []);

  const loadStats = async () => {
    setLoading(true);
    try {
      const res = await analyticsApi.getDashboard();
      setStats(res.data);
    } catch {
      toast.error('Failed to load analytics');
    } finally {
      setLoading(false);
    }
  };

  if (!isModerator) return null;

  const tagChartData = stats?.trendingTags?.slice(0, 8).map(t => ({
    name: t.tag, count: parseInt(t.count),
  })) || [];

  const sentimentData = [
    { name: 'Positive', value: 62 },
    { name: 'Neutral', value: 28 },
    { name: 'Negative', value: 10 },
  ];

  return (
    <div style={{ maxWidth: 1200, margin: '0 auto', padding: '24px' }}>
      {/* Header */}
      <div style={{ marginBottom: 24 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <BarChart2 size={22} color="var(--accent2)" />
          <h1 style={{ fontSize: 22, fontWeight: 700, color: 'var(--text)' }}>Analytics Dashboard</h1>
          <span className="badge badge-accent">
            {user?.role === 'ADMIN' ? 'ADMIN' : 'MODERATOR'}
          </span>
        </div>
        <p style={{ fontSize: 13, color: 'var(--text2)', marginTop: 4 }}>
          Platform overview, trending content, and moderation insights
        </p>
      </div>

      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', padding: 80 }}>
          <div className="spinner" style={{ width: 36, height: 36 }} />
        </div>
      ) : (
        <>
          {/* Stat cards */}
          <div style={{
            display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 14, marginBottom: 24,
          }}>
            <StatCard icon={MessageSquare} label="Total Questions" value={stats?.totalQuestions} color="var(--accent)" sub="All time" />
            <StatCard icon={FileText} label="Total Answers" value={stats?.totalAnswers} color="var(--teal)" sub="All time" />
            <StatCard icon={Users} label="Total Users" value={stats?.totalUsers} color="var(--green)" sub={`+${stats?.newUsersToday} today`} />
            <StatCard icon={TrendingUp} label="Questions Today" value={stats?.questionsToday} color="var(--yellow)" />
            <StatCard icon={Flag} label="Flagged Content" value={stats?.flaggedQuestions} color="var(--red)" sub="Needs review" />
            <StatCard icon={Zap} label="AI Moderated" value={stats?.moderatedAnswers} color="var(--accent2)" sub="Auto-filtered" />
          </div>

          {/* Charts row */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 24 }}>
            {/* Trending tags */}
            <div className="card" style={{ padding: '20px' }}>
              <h3 style={{ fontSize: 15, fontWeight: 600, color: 'var(--text)', marginBottom: 16 }}>
                Trending Tags
              </h3>
              {tagChartData.length > 0 ? (
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={tagChartData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                    <XAxis dataKey="name" tick={{ fill: 'var(--text3)', fontSize: 11 }} />
                    <YAxis tick={{ fill: 'var(--text3)', fontSize: 11 }} />
                    <Tooltip
                      contentStyle={{ background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: 8 }}
                      labelStyle={{ color: 'var(--text)' }}
                      itemStyle={{ color: 'var(--accent2)' }}
                    />
                    <Bar dataKey="count" fill="var(--accent)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div style={{ height: 220, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text3)', fontSize: 13 }}>
                  No tag data yet
                </div>
              )}
            </div>

            {/* Sentiment */}
            <div className="card" style={{ padding: '20px' }}>
              <h3 style={{ fontSize: 15, fontWeight: 600, color: 'var(--text)', marginBottom: 16 }}>
                AI Sentiment Analysis
              </h3>
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie
                    data={sentimentData}
                    cx="50%" cy="50%"
                    innerRadius={55} outerRadius={85}
                    paddingAngle={3} dataKey="value"
                  >
                    {sentimentData.map((_, i) => (
                      <Cell key={i} fill={COLORS[i]} />
                    ))}
                  </Pie>
                  <Legend
                    formatter={v => <span style={{ color: 'var(--text2)', fontSize: 12 }}>{v}</span>}
                  />
                  <Tooltip
                    contentStyle={{ background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: 8 }}
                    formatter={(v) => [`${v}%`, '']}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Top users + moderation panel */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            {/* Top users */}
            <div className="card" style={{ padding: '20px' }}>
              <h3 style={{ fontSize: 15, fontWeight: 600, color: 'var(--text)', marginBottom: 14 }}>
                Top Contributors
              </h3>
              {stats?.topUsers?.length > 0 ? (
                stats.topUsers.map((u, i) => (
                  <div key={u.username} style={{
                    display: 'flex', alignItems: 'center', gap: 10,
                    padding: '8px 0', borderBottom: '1px solid var(--border)',
                  }}>
                    <span style={{ fontSize: 12, color: 'var(--text3)', width: 20 }}>#{i + 1}</span>
                    <div style={{
                      width: 30, height: 30, borderRadius: '50%',
                      background: COLORS[i % COLORS.length], display: 'flex',
                      alignItems: 'center', justifyContent: 'center',
                      fontSize: 12, fontWeight: 700, color: 'white',
                    }}>
                      {u.displayName[0].toUpperCase()}
                    </div>
                    <span style={{ flex: 1, fontSize: 13, color: 'var(--text)' }}>{u.displayName}</span>
                    <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--accent2)' }}>
                      {u.reputation} rep
                    </span>
                  </div>
                ))
              ) : (
                <p style={{ fontSize: 13, color: 'var(--text3)' }}>No users yet</p>
              )}
            </div>

            {/* Quick moderation */}
            <FlaggedPanel onRefresh={loadStats} />
          </div>
        </>
      )}
    </div>
  );
}

function FlaggedPanel({ onRefresh }) {
  const [flagged, setFlagged] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadFlagged(); }, []);

  const loadFlagged = async () => {
    try {
      const res = await analyticsApi.getFlagged();
      setFlagged(res.data);
    } catch {} finally { setLoading(false); }
  };

  const approve = async id => {
    try {
      await analyticsApi.approveQuestion(id);
      setFlagged(f => f.filter(q => q.id !== id));
      toast.success('Question approved');
      onRefresh();
    } catch { toast.error('Failed'); }
  };

  const remove = async id => {
    try {
      await analyticsApi.removeQuestion(id);
      setFlagged(f => f.filter(q => q.id !== id));
      toast.success('Question removed');
      onRefresh();
    } catch { toast.error('Failed'); }
  };

  return (
    <div className="card" style={{ padding: '20px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
        <Shield size={15} color="var(--red)" />
        <h3 style={{ fontSize: 15, fontWeight: 600, color: 'var(--text)' }}>
          Flagged Content
        </h3>
        {flagged.length > 0 && (
          <span className="badge badge-red" style={{ marginLeft: 4 }}>{flagged.length}</span>
        )}
      </div>

      {loading ? (
        <div className="spinner" />
      ) : flagged.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '20px 0', color: 'var(--text3)', fontSize: 13 }}>
          <CheckCircle size={28} style={{ opacity: 0.3, marginBottom: 8 }} />
          <p>No flagged content. All clear!</p>
        </div>
      ) : (
        flagged.slice(0, 5).map(q => (
          <div key={q.id} style={{
            padding: '10px 0', borderBottom: '1px solid var(--border)',
          }}>
            <p style={{ fontSize: 13, color: 'var(--text)', marginBottom: 4, lineHeight: 1.4 }}>
              {q.title?.substring(0, 60)}{q.title?.length > 60 ? '...' : ''}
            </p>
            {q.moderationNote && (
              <p style={{ fontSize: 11, color: 'var(--red)', marginBottom: 6 }}>
                AI: {q.moderationNote}
              </p>
            )}
            <div style={{ display: 'flex', gap: 6 }}>
              <button className="btn btn-sm" onClick={() => approve(q.id)}
                style={{ background: 'var(--green-bg)', color: 'var(--green)', fontSize: 11, padding: '3px 10px' }}>
                Approve
              </button>
              <button className="btn btn-danger btn-sm" onClick={() => remove(q.id)}
                style={{ fontSize: 11, padding: '3px 10px' }}>
                Remove
              </button>
            </div>
          </div>
        ))
      )}
    </div>
  );
}
