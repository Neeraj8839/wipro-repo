import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { questionsApi, answersApi } from '../api';
import { useAuth } from '../context/AuthContext';
import { Zap, Tag, Wand2, X, Plus, AlertCircle } from 'lucide-react';
import toast from 'react-hot-toast';

export default function AskQuestionPage() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [form, setForm] = useState({ title: '', body: '', tags: [] });
  const [tagInput, setTagInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [aiLoading, setAiLoading] = useState({ tags: false, grammar: false });
  const [errors, setErrors] = useState({});

  if (!user) {
    navigate('/login');
    return null;
  }

  const validate = () => {
    const e = {};
    if (form.title.trim().length < 10) e.title = 'Title must be at least 10 characters';
    if (form.body.trim().length < 20) e.body = 'Body must be at least 20 characters';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async e => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    try {
      const res = await questionsApi.create(form);
      toast.success('Question posted! AI tags were auto-suggested.');
      navigate(`/questions/${res.data.id}`);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to post question');
    } finally {
      setLoading(false);
    }
  };

  const predictTags = async () => {
    if (!form.title || !form.body) {
      toast.error('Add title and body first');
      return;
    }
    setAiLoading(a => ({ ...a, tags: true }));
    try {
      // Tags will be AI-predicted by backend on submission
      // Here we show a preview via grammar endpoint as demonstration
      toast.success('Tags will be AI-predicted when you submit!');
    } finally {
      setAiLoading(a => ({ ...a, tags: false }));
    }
  };

  const enhanceGrammar = async () => {
    if (!form.body) { toast.error('Add body text first'); return; }
    setAiLoading(a => ({ ...a, grammar: true }));
    try {
      const res = await answersApi.enhanceGrammar(form.body);
      setForm(f => ({ ...f, body: res.data.enhanced }));
      toast.success('Grammar enhanced by AI!');
    } catch {
      toast.error('AI enhancement failed');
    } finally {
      setAiLoading(a => ({ ...a, grammar: false }));
    }
  };

  const addTag = () => {
    const t = tagInput.trim().toLowerCase().replace(/\s+/g, '-');
    if (t && !form.tags.includes(t) && form.tags.length < 5) {
      setForm(f => ({ ...f, tags: [...f.tags, t] }));
      setTagInput('');
    }
  };

  const removeTag = tag => setForm(f => ({ ...f, tags: f.tags.filter(t => t !== tag) }));

  return (
    <div style={{ maxWidth: 860, margin: '0 auto', padding: '24px' }}>
      {/* Header */}
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 22, fontWeight: 700, color: 'var(--text)' }}>Ask a Question</h1>
        <p style={{ fontSize: 13, color: 'var(--text2)', marginTop: 4 }}>
          Be specific and clear. AI will auto-suggest tags and moderate content.
        </p>
      </div>

      {/* Tips card */}
      <div className="card" style={{
        marginBottom: 20, padding: '14px 18px',
        background: 'rgba(108,99,255,0.06)', borderColor: 'rgba(108,99,255,0.2)',
      }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
          <AlertCircle size={15} color="var(--accent2)" style={{ marginTop: 1, flexShrink: 0 }} />
          <div style={{ fontSize: 13, color: 'var(--text2)', lineHeight: 1.6 }}>
            <strong style={{ color: 'var(--accent2)' }}>Tips for a great question:</strong>
            {' '}Summarize the problem in the title · Describe what you tried · Include relevant code/errors ·
            Leave tags empty to let AI suggest them
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
        {/* Title */}
        <div className="card" style={{ padding: '20px' }}>
          <label style={{ display: 'block', fontSize: 14, fontWeight: 600, color: 'var(--text)', marginBottom: 4 }}>
            Title <span style={{ color: 'var(--red)' }}>*</span>
          </label>
          <p style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 10 }}>
            Be specific. Imagine asking a colleague.
          </p>
          <input
            value={form.title}
            onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
            placeholder="e.g. How do I fix NullPointerException in Spring Boot service layer?"
            style={{ fontSize: 15 }}
          />
          {errors.title && (
            <p style={{ fontSize: 12, color: 'var(--red)', marginTop: 6 }}>{errors.title}</p>
          )}
        </div>

        {/* Body */}
        <div className="card" style={{ padding: '20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
            <label style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)' }}>
              Body <span style={{ color: 'var(--red)' }}>*</span>
            </label>
            <button
              type="button"
              className="btn btn-secondary btn-sm"
              onClick={enhanceGrammar}
              disabled={aiLoading.grammar}
            >
              {aiLoading.grammar
                ? <><span className="spinner" style={{ width: 12, height: 12 }} /> Enhancing...</>
                : <><Wand2 size={13} /> AI Enhance Grammar</>
              }
            </button>
          </div>
          <p style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 10 }}>
            Include all information someone needs to answer your question. Supports Markdown.
          </p>
          <textarea
            value={form.body}
            onChange={e => setForm(f => ({ ...f, body: e.target.value }))}
            placeholder="Describe your problem in detail. What did you try? What happened? What did you expect?"
            rows={12}
            style={{ resize: 'vertical', fontFamily: 'var(--mono)', fontSize: 13, lineHeight: 1.7 }}
          />
          {errors.body && (
            <p style={{ fontSize: 12, color: 'var(--red)', marginTop: 6 }}>{errors.body}</p>
          )}
        </div>

        {/* Tags */}
        <div className="card" style={{ padding: '20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
            <label style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)' }}>
              Tags
            </label>
            <span className="ai-badge">
              <Zap size={10} /> AI auto-suggests if empty
            </span>
          </div>
          <p style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 10 }}>
            Add up to 5 tags. Leave empty and AI will predict them for you.
          </p>

          {/* Tag chips */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 10 }}>
            {form.tags.map(tag => (
              <span key={tag} className="tag" style={{ cursor: 'default' }}>
                {tag}
                <button
                  type="button"
                  onClick={() => removeTag(tag)}
                  style={{ background: 'none', padding: '0 0 0 4px', color: 'inherit', marginLeft: 2 }}
                >
                  <X size={11} />
                </button>
              </span>
            ))}
          </div>

          {form.tags.length < 5 && (
            <div style={{ display: 'flex', gap: 8 }}>
              <input
                value={tagInput}
                onChange={e => setTagInput(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); addTag(); } }}
                placeholder="e.g. java, spring-boot, react"
                style={{ flex: 1 }}
              />
              <button type="button" className="btn btn-secondary btn-sm" onClick={addTag}>
                <Plus size={13} /> Add
              </button>
            </div>
          )}

          {/* Common tag suggestions */}
          <div style={{ marginTop: 10 }}>
            <span style={{ fontSize: 11, color: 'var(--text3)', marginRight: 6 }}>Common:</span>
            {['java', 'python', 'javascript', 'react', 'spring-boot', 'mysql', 'docker', 'api'].map(t => (
              <button
                key={t} type="button"
                className="tag"
                style={{ marginRight: 4, marginBottom: 4 }}
                onClick={() => {
                  if (!form.tags.includes(t) && form.tags.length < 5) {
                    setForm(f => ({ ...f, tags: [...f.tags, t] }));
                  }
                }}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Submit */}
        <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
          <button type="button" className="btn btn-secondary"
            onClick={() => navigate(-1)}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading
              ? <><span className="spinner" style={{ width: 14, height: 14 }} /> Posting...</>
              : <><Zap size={14} /> Post Question</>
            }
          </button>
        </div>
      </form>
    </div>
  );
}
