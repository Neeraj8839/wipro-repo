import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { questionsApi, answersApi } from '../api';
import { useAuth } from '../context/AuthContext';
import ReactMarkdown from 'react-markdown';
import {
  ThumbsUp, ThumbsDown, Check, Zap, Wand2, FileText,
  Clock, Eye, User, MessageSquare, ArrowLeft, Trash2
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import toast from 'react-hot-toast';

function VoteButtons({ count, onUpvote, onDownvote, vertical = true }) {
  return (
    <div style={{
      display: 'flex',
      flexDirection: vertical ? 'column' : 'row',
      alignItems: 'center', gap: 4,
    }}>
      <button className="btn btn-ghost btn-icon" onClick={onUpvote}
        title="Upvote" style={{ color: 'var(--text2)' }}>
        <ThumbsUp size={16} />
      </button>
      <span style={{ fontSize: 16, fontWeight: 700, color: 'var(--text)', minWidth: 20, textAlign: 'center' }}>
        {count}
      </span>
      <button className="btn btn-ghost btn-icon" onClick={onDownvote}
        title="Downvote" style={{ color: 'var(--text2)' }}>
        <ThumbsDown size={16} />
      </button>
    </div>
  );
}

function AnswerCard({ answer, isQuestionAuthor, onAccept, onVote }) {
  const [summarizing, setSummarizing] = useState(false);
  const [summary, setSummary] = useState('');

  const handleSummarize = async () => {
    setSummarizing(true);
    try {
      const res = await answersApi.summarize(answer.id);
      setSummary(res.data.summary);
    } catch { toast.error('Summary failed'); }
    finally { setSummarizing(false); }
  };

  return (
    <div className="card fade-in" style={{
      marginBottom: 16, padding: '20px 24px',
      borderLeft: answer.isAccepted ? '3px solid var(--green)' : answer.isAiGenerated ? '3px solid var(--accent)' : '1px solid var(--border)',
      borderRadius: answer.isAccepted || answer.isAiGenerated ? '0 12px 12px 0' : undefined,
    }}>
      <div style={{ display: 'flex', gap: 16 }}>
        {/* Vote column */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, minWidth: 40 }}>
          <VoteButtons
            count={answer.voteCount}
            onUpvote={() => onVote(answer.id, 1)}
            onDownvote={() => onVote(answer.id, -1)}
          />
          {answer.isAccepted && (
            <div title="Accepted answer" style={{ marginTop: 4, color: 'var(--green)' }}>
              <Check size={20} />
            </div>
          )}
        </div>

        {/* Content */}
        <div style={{ flex: 1, minWidth: 0 }}>
          {/* Badges */}
          <div style={{ display: 'flex', gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
            {answer.isAiGenerated && (
              <span className="ai-badge"><Zap size={10} /> AI Generated</span>
            )}
            {answer.isAccepted && (
              <span className="badge badge-green"><Check size={10} /> Accepted Answer</span>
            )}
          </div>

          {/* Answer body */}
          <div className="markdown" style={{ fontSize: 14, lineHeight: 1.8 }}>
            <ReactMarkdown>{answer.body}</ReactMarkdown>
          </div>

          {/* AI Summary */}
          {summary && (
            <div style={{
              marginTop: 12, padding: '10px 14px',
              background: 'var(--accent-bg)', borderRadius: 8,
              border: '1px solid rgba(108,99,255,0.2)',
            }}>
              <p style={{ fontSize: 12, color: 'var(--accent2)', fontWeight: 600, marginBottom: 4 }}>
                AI Summary
              </p>
              <p style={{ fontSize: 13, color: 'var(--text2)' }}>{summary}</p>
            </div>
          )}

          {/* Footer */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: 8,
            marginTop: 16, paddingTop: 12, borderTop: '1px solid var(--border)',
          }}>
            {/* Accept button */}
            {isQuestionAuthor && !answer.isAccepted && (
              <button className="btn btn-secondary btn-sm" onClick={() => onAccept(answer.id)}
                style={{ color: 'var(--green)' }}>
                <Check size={13} /> Accept
              </button>
            )}

            {/* Summarize */}
            <button className="btn btn-ghost btn-sm" onClick={handleSummarize} disabled={summarizing}>
              {summarizing
                ? <><span className="spinner" style={{ width: 12, height: 12 }} /> Summarizing...</>
                : <><FileText size={13} /> AI Summarize</>
              }
            </button>

            <span style={{ marginLeft: 'auto', fontSize: 12, color: 'var(--text3)' }}>
              answered by{' '}
              <span style={{ color: 'var(--accent2)' }}>{answer.authorName}</span>
              {' · '}{answer.createdAt && formatDistanceToNow(new Date(answer.createdAt), { addSuffix: true })}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function QuestionDetailPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [question, setQuestion] = useState(null);
  const [answers, setAnswers] = useState([]);
  const [similar, setSimilar] = useState([]);
  const [newAnswer, setNewAnswer] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [aiGenerating, setAiGenerating] = useState(false);
  const [enhancing, setEnhancing] = useState(false);

  useEffect(() => {
    loadAll();
  }, [id]);

  const loadAll = async () => {
    setLoading(true);
    try {
      const [qRes, aRes, sRes] = await Promise.all([
        questionsApi.getById(id),
        answersApi.getByQuestion(id),
        questionsApi.getSimilar(id),
      ]);
      setQuestion(qRes.data);
      setAnswers(aRes.data);
      setSimilar(sRes.data);
    } catch {
      toast.error('Failed to load question');
      navigate('/');
    } finally {
      setLoading(false);
    }
  };

  const handleVoteQuestion = async delta => {
    if (!user) { toast.error('Login to vote'); return; }
    try {
      const res = await questionsApi.vote(id, delta);
      setQuestion(q => ({ ...q, voteCount: res.data.voteCount }));
    } catch { toast.error('Vote failed'); }
  };

  const handleVoteAnswer = async (answerId, delta) => {
    if (!user) { toast.error('Login to vote'); return; }
    try {
      const res = await answersApi.vote(answerId, delta);
      setAnswers(prev => prev.map(a => a.id === answerId ? { ...a, voteCount: res.data.voteCount } : a));
    } catch { toast.error('Vote failed'); }
  };

  const handleAccept = async answerId => {
    try {
      await answersApi.accept(answerId);
      setAnswers(prev => prev.map(a => ({ ...a, isAccepted: a.id === answerId })));
      setQuestion(q => ({ ...q, isSolved: true }));
      toast.success('Answer accepted!');
    } catch (e) {
      toast.error(e.response?.data?.message || 'Failed to accept');
    }
  };

  const handleSubmitAnswer = async e => {
    e.preventDefault();
    if (!user) { toast.error('Login to answer'); return; }
    if (newAnswer.trim().length < 10) { toast.error('Answer must be at least 10 characters'); return; }
    setSubmitting(true);
    try {
      const res = await answersApi.create(id, { body: newAnswer });
      setAnswers(prev => [...prev, res.data]);
      setNewAnswer('');
      toast.success('Answer posted!');
    } catch (e) {
      toast.error(e.response?.data?.message || 'Failed to post answer');
    } finally {
      setSubmitting(false);
    }
  };

  const handleGenerateAiAnswer = async () => {
    setAiGenerating(true);
    try {
      const res = await answersApi.generateAi(id);
      setAnswers(prev => [res.data, ...prev]);
      toast.success('AI answer generated!');
    } catch {
      toast.error('AI generation failed');
    } finally {
      setAiGenerating(false);
    }
  };

  const handleEnhanceGrammar = async () => {
    if (!newAnswer) { toast.error('Write something first'); return; }
    setEnhancing(true);
    try {
      const res = await answersApi.enhanceGrammar(newAnswer);
      setNewAnswer(res.data.enhanced);
      toast.success('Grammar enhanced!');
    } catch { toast.error('Enhancement failed'); }
    finally { setEnhancing(false); }
  };

  const handleDeleteQuestion = async () => {
    if (!confirm('Delete this question?')) return;
    try {
      await questionsApi.delete(id);
      toast.success('Question deleted');
      navigate('/');
    } catch (e) { toast.error(e.response?.data?.message || 'Delete failed'); }
  };

  if (loading) return (
    <div style={{ display: 'flex', justifyContent: 'center', padding: 80 }}>
      <div className="spinner" style={{ width: 36, height: 36 }} />
    </div>
  );

  if (!question) return null;

  const isAuthor = user?.userId === question.authorId;

  return (
    <div style={{ maxWidth: 1100, margin: '0 auto', padding: '24px', display: 'flex', gap: 24 }}>
      {/* Main */}
      <div style={{ flex: 1, minWidth: 0 }}>
        {/* Back */}
        <button className="btn btn-ghost btn-sm" onClick={() => navigate(-1)}
          style={{ marginBottom: 16 }}>
          <ArrowLeft size={14} /> Back
        </button>

        {/* Question */}
        <div className="card" style={{ marginBottom: 24, padding: '24px 28px' }}>
          <div style={{ display: 'flex', gap: 20 }}>
            {/* Vote */}
            <VoteButtons
              count={question.voteCount}
              onUpvote={() => handleVoteQuestion(1)}
              onDownvote={() => handleVoteQuestion(-1)}
            />

            {/* Content */}
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 8, marginBottom: 12 }}>
                <h1 style={{ fontSize: 20, fontWeight: 700, color: 'var(--text)', lineHeight: 1.4, flex: 1 }}>
                  {question.title}
                </h1>
                {isAuthor && (
                  <button className="btn btn-danger btn-sm btn-icon" onClick={handleDeleteQuestion}>
                    <Trash2 size={14} />
                  </button>
                )}
              </div>

              {/* Meta */}
              <div style={{ display: 'flex', gap: 16, marginBottom: 16, flexWrap: 'wrap' }}>
                {question.isSolved && <span className="badge badge-green">Solved</span>}
                {question.status === 'FLAGGED' && <span className="badge badge-red">Flagged</span>}
                <span style={{ fontSize: 12, color: 'var(--text3)', display: 'flex', alignItems: 'center', gap: 4 }}>
                  <Clock size={12} />
                  {question.createdAt && formatDistanceToNow(new Date(question.createdAt), { addSuffix: true })}
                </span>
                <span style={{ fontSize: 12, color: 'var(--text3)', display: 'flex', alignItems: 'center', gap: 4 }}>
                  <Eye size={12} /> {question.viewCount} views
                </span>
                <span style={{ fontSize: 12, color: 'var(--text3)', display: 'flex', alignItems: 'center', gap: 4 }}>
                  <MessageSquare size={12} /> {answers.length} answers
                </span>
              </div>

              <div className="markdown" style={{ fontSize: 14, lineHeight: 1.9 }}>
                <ReactMarkdown>{question.body}</ReactMarkdown>
              </div>

              {/* Tags */}
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 16 }}>
                {question.tags?.map(t => (
                  <Link key={t} to={`/search?q=${t}`} className="tag">{t}</Link>
                ))}
              </div>

              <div style={{
                marginTop: 16, paddingTop: 12, borderTop: '1px solid var(--border)',
                fontSize: 12, color: 'var(--text3)',
              }}>
                Asked by <span style={{ color: 'var(--accent2)' }}>{question.authorName}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Answers header */}
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 16 }}>
          <h2 style={{ fontSize: 17, fontWeight: 700, color: 'var(--text)' }}>
            {answers.length} Answer{answers.length !== 1 ? 's' : ''}
          </h2>
          <button
            className="btn btn-secondary btn-sm"
            style={{ marginLeft: 'auto' }}
            onClick={handleGenerateAiAnswer}
            disabled={aiGenerating}
          >
            {aiGenerating
              ? <><span className="spinner" style={{ width: 12, height: 12 }} /> Generating...</>
              : <><Zap size={13} /> Get AI Answer</>
            }
          </button>
        </div>

        {/* Answers list */}
        {answers.length === 0 ? (
          <div className="card" style={{ textAlign: 'center', padding: 32, color: 'var(--text2)' }}>
            <MessageSquare size={36} style={{ opacity: 0.3, marginBottom: 8 }} />
            <p>No answers yet.</p>
            <button className="btn btn-primary btn-sm" style={{ marginTop: 12 }}
              onClick={handleGenerateAiAnswer} disabled={aiGenerating}>
              <Zap size={13} /> Generate AI Answer
            </button>
          </div>
        ) : (
          answers.map(a => (
            <AnswerCard
              key={a.id}
              answer={a}
              isQuestionAuthor={isAuthor}
              onAccept={handleAccept}
              onVote={handleVoteAnswer}
            />
          ))
        )}

        {/* Post answer */}
        <div className="card" style={{ marginTop: 24, padding: '24px' }}>
          <h3 style={{ fontSize: 16, fontWeight: 600, color: 'var(--text)', marginBottom: 16 }}>
            Your Answer
          </h3>

          {user ? (
            <form onSubmit={handleSubmitAnswer}>
              <textarea
                value={newAnswer}
                onChange={e => setNewAnswer(e.target.value)}
                placeholder="Write your answer here... Markdown is supported."
                rows={10}
                style={{ resize: 'vertical', fontFamily: 'var(--mono)', fontSize: 13, lineHeight: 1.7 }}
              />
              <div style={{ display: 'flex', gap: 8, marginTop: 12, justifyContent: 'flex-end' }}>
                <button type="button" className="btn btn-secondary btn-sm"
                  onClick={handleEnhanceGrammar} disabled={enhancing}>
                  {enhancing
                    ? <><span className="spinner" style={{ width: 12, height: 12 }} /> Enhancing...</>
                    : <><Wand2 size={13} /> Enhance Grammar</>
                  }
                </button>
                <button type="submit" className="btn btn-primary" disabled={submitting}>
                  {submitting
                    ? <><span className="spinner" style={{ width: 14, height: 14 }} /> Posting...</>
                    : 'Post Answer'
                  }
                </button>
              </div>
            </form>
          ) : (
            <div style={{ textAlign: 'center', padding: 20, color: 'var(--text2)' }}>
              <Link to="/login" className="btn btn-primary">Login to Answer</Link>
            </div>
          )}
        </div>
      </div>

      {/* Sidebar */}
      <div style={{ width: 260, flexShrink: 0 }}>
        {/* Similar questions */}
        {similar.length > 0 && (
          <div className="card" style={{ padding: '18px' }}>
            <h3 style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)', marginBottom: 12 }}>
              Similar Questions
            </h3>
            {similar.map(q => (
              <Link key={q.id} to={`/questions/${q.id}`} style={{
                display: 'block', padding: '8px 0',
                borderBottom: '1px solid var(--border)',
                fontSize: 13, color: 'var(--text2)',
                lineHeight: 1.4,
              }}>
                {q.title}
                <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 3 }}>
                  {q.voteCount} votes · {q.answerCount} answers
                </div>
              </Link>
            ))}
          </div>
        )}

        {/* Tags card */}
        {question.tags?.length > 0 && (
          <div className="card" style={{ padding: '18px', marginTop: 12 }}>
            <h3 style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)', marginBottom: 10 }}>Tags</h3>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
              {question.tags.map(t => (
                <Link key={t} to={`/search?q=${t}`} className="tag">{t}</Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
