import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { questionsApi } from '../api';
import { useAuth } from '../context/AuthContext';
import { MessageSquare, ThumbsUp, Eye, Tag, Plus, TrendingUp, Clock, Filter, Zap } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import toast from 'react-hot-toast';

function QuestionCard({ q }) {
  const navigate = useNavigate();
  return (
    <div
      className="card fade-in"
      onClick={() => navigate(`/questions/${q.id}`)}
      style={{
        cursor: 'pointer', marginBottom: 12, padding: '16px 20px',
        transition: 'all 0.15s',
        borderColor: q.isSolved ? 'rgba(34,197,94,0.3)' : 'var(--border)',
      }}
      onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--accent)'}
      onMouseLeave={e => e.currentTarget.style.borderColor = q.isSolved ? 'rgba(34,197,94,0.3)' : 'var(--border)'}
    >
      <div style={{ display: 'flex', gap: 16 }}>
        {/* Stats */}
        <div style={{
          display: 'flex', flexDirection: 'column', gap: 8,
          minWidth: 64, alignItems: 'center', justifyContent: 'flex-start',
          paddingTop: 2,
        }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--text)' }}>{q.voteCount}</div>
            <div style={{ fontSize: 11, color: 'var(--text3)' }}>votes</div>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{
              fontSize: 16, fontWeight: 700,
              color: q.answerCount > 0 ? (q.isSolved ? 'var(--green)' : 'var(--text)') : 'var(--text3)',
            }}>
              {q.answerCount}
            </div>
            <div style={{ fontSize: 11, color: 'var(--text3)' }}>answers</div>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--text3)' }}>{q.viewCount}</div>
            <div style={{ fontSize: 11, color: 'var(--text3)' }}>views</div>
          </div>
        </div>

        {/* Content */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 8, marginBottom: 6 }}>
            {q.isSolved && <span className="badge badge-green">Solved</span>}
            {q.status === 'FLAGGED' && <span className="badge badge-red">Flagged</span>}
            <h3 style={{
              fontSize: 15, fontWeight: 600, color: 'var(--text)',
              lineHeight: 1.4, flex: 1,
            }}>
              {q.title}
            </h3>
          </div>

          <p style={{
            fontSize: 13, color: 'var(--text2)',
            overflow: 'hidden', textOverflow: 'ellipsis',
            display: '-webkit-box', WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical', marginBottom: 10,
            lineHeight: 1.5,
          }}>
            {q.body}
          </p>

          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
            {q.tags?.slice(0, 5).map(tag => (
              <span key={tag} className="tag" onClick={e => { e.stopPropagation(); }}>
                {tag}
              </span>
            ))}
            <span style={{ marginLeft: 'auto', fontSize: 12, color: 'var(--text3)' }}>
              by <span style={{ color: 'var(--accent2)' }}>{q.authorName}</span>
              {' · '}
              {formatDistanceToNow(new Date(q.createdAt), { addSuffix: true })}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function HomePage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [sort, setSort] = useState('latest');
  const [trendingTags, setTrendingTags] = useState([]);

  useEffect(() => {
    loadQuestions();
    loadTrendingTags();
  }, [page, sort]);

  const loadQuestions = async () => {
    setLoading(true);
    try {
      const res = await questionsApi.getAll(page, 10, sort);
      setQuestions(res.data.content);
      setTotalPages(res.data.totalPages);
    } catch (e) {
      toast.error('Failed to load questions');
    } finally {
      setLoading(false);
    }
  };

  const loadTrendingTags = async () => {
    try {
      const res = await questionsApi.getTrendingTags();
      setTrendingTags(res.data);
    } catch (e) {}
  };

  return (
    <div style={{ display: 'flex', gap: 24, padding: '24px', maxWidth: 1200, margin: '0 auto' }}>
      {/* Main content */}
      <div style={{ flex: 1, minWidth: 0 }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 20 }}>
          <div>
            <h1 style={{ fontSize: 20, fontWeight: 700, color: 'var(--text)' }}>All Questions</h1>
            <p style={{ fontSize: 13, color: 'var(--text2)', marginTop: 2 }}>
              {questions.length > 0 ? 'Showing the latest community questions' : 'No questions yet'}
            </p>
          </div>
          <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
            {user && (
              <button
                className="btn btn-primary btn-sm"
                onClick={() => navigate('/ask')}
              >
                <Plus size={14} /> Ask Question
              </button>
            )}
          </div>
        </div>

        {/* Sort tabs */}
        <div style={{
          display: 'flex', gap: 4, marginBottom: 16,
          background: 'var(--bg2)', borderRadius: 8, padding: 4,
          border: '1px solid var(--border)', alignSelf: 'flex-start',
          width: 'fit-content',
        }}>
          {[
            { key: 'latest', label: 'Latest', Icon: Clock },
            { key: 'votes', label: 'Top Voted', Icon: TrendingUp },
          ].map(({ key, label, Icon }) => (
            <button
              key={key}
              onClick={() => { setSort(key); setPage(0); }}
              style={{
                display: 'flex', alignItems: 'center', gap: 5,
                padding: '5px 14px', borderRadius: 6, fontSize: 13,
                background: sort === key ? 'var(--accent-bg)' : 'transparent',
                color: sort === key ? 'var(--accent2)' : 'var(--text2)',
                border: sort === key ? '1px solid rgba(108,99,255,0.3)' : '1px solid transparent',
              }}
            >
              <Icon size={13} /> {label}
            </button>
          ))}
        </div>

        {/* Questions list */}
        {loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: 48 }}>
            <div className="spinner" style={{ width: 32, height: 32 }} />
          </div>
        ) : questions.length === 0 ? (
          <div className="card" style={{ textAlign: 'center', padding: 48, color: 'var(--text2)' }}>
            <MessageSquare size={48} style={{ opacity: 0.3, marginBottom: 12 }} />
            <p>No questions yet. Be the first to ask!</p>
            {user && (
              <button className="btn btn-primary" style={{ marginTop: 16 }}
                onClick={() => navigate('/ask')}>
                <Plus size={14} /> Ask Question
              </button>
            )}
          </div>
        ) : (
          questions.map(q => <QuestionCard key={q.id} q={q} />)
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div style={{ display: 'flex', gap: 8, justifyContent: 'center', marginTop: 24 }}>
            <button className="btn btn-secondary btn-sm"
              disabled={page === 0} onClick={() => setPage(p => p - 1)}>
              Previous
            </button>
            <span style={{ padding: '6px 12px', fontSize: 13, color: 'var(--text2)' }}>
              Page {page + 1} of {totalPages}
            </span>
            <button className="btn btn-secondary btn-sm"
              disabled={page >= totalPages - 1} onClick={() => setPage(p => p + 1)}>
              Next
            </button>
          </div>
        )}
      </div>

      {/* Sidebar */}
      <div style={{ width: 260, flexShrink: 0 }}>
        {/* AI Features card */}
        <div className="card" style={{
          marginBottom: 16,
          background: 'linear-gradient(135deg, rgba(108,99,255,0.1), rgba(20,184,166,0.1))',
          borderColor: 'rgba(108,99,255,0.2)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
            <Zap size={16} color="var(--accent2)" />
            <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text)' }}>AI-Powered</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[
              'Auto tag prediction',
              'AI-generated answers',
              'Content moderation',
              'Smart recommendations',
              'Grammar enhancement',
            ].map(f => (
              <div key={f} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <div style={{ width: 5, height: 5, borderRadius: '50%', background: 'var(--teal)' }} />
                <span style={{ fontSize: 12, color: 'var(--text2)' }}>{f}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Trending Tags */}
        <div className="card">
          <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 12, color: 'var(--text)' }}>
            Trending Tags
          </h3>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            {trendingTags.slice(0, 15).map(([tag, count]) => (
              <span
                key={tag} className="tag"
                onClick={() => navigate(`/search?q=${tag}`)}
              >
                {tag}
                <span style={{ marginLeft: 4, fontSize: 10, opacity: 0.7 }}>{count}</span>
              </span>
            ))}
            {trendingTags.length === 0 && (
              <p style={{ fontSize: 12, color: 'var(--text3)' }}>No tags yet</p>
            )}
          </div>
        </div>

        {!user && (
          <div className="card" style={{ marginTop: 16, textAlign: 'center' }}>
            <p style={{ fontSize: 13, color: 'var(--text2)', marginBottom: 12 }}>
              Join to ask questions and get AI-powered answers
            </p>
            <button className="btn btn-primary btn-sm" style={{ width: '100%', justifyContent: 'center' }}
              onClick={() => navigate('/register')}>
              Get Started Free
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
