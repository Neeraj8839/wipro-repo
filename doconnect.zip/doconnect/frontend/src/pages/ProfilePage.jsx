import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { User, Mail, Shield, Star, Calendar } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export default function ProfilePage() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  if (!user) { navigate('/login'); return null; }

  return (
    <div style={{ maxWidth: 700, margin: '0 auto', padding: '24px' }}>
      <h1 style={{ fontSize: 22, fontWeight: 700, color: 'var(--text)', marginBottom: 24 }}>Profile</h1>

      <div className="card" style={{ padding: '28px', marginBottom: 16 }}>
        {/* Avatar */}
        <div style={{ display: 'flex', gap: 20, alignItems: 'flex-start', marginBottom: 24 }}>
          <div style={{
            width: 72, height: 72, borderRadius: '50%',
            background: 'linear-gradient(135deg, var(--accent), var(--teal))',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 28, fontWeight: 700, color: 'white', flexShrink: 0,
          }}>
            {(user.displayName || user.username)[0].toUpperCase()}
          </div>
          <div>
            <h2 style={{ fontSize: 20, fontWeight: 700, color: 'var(--text)' }}>
              {user.displayName || user.username}
            </h2>
            <p style={{ fontSize: 13, color: 'var(--text2)', marginTop: 2 }}>@{user.username}</p>
            <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
              <span className={`badge ${user.role === 'ADMIN' ? 'badge-red' : user.role === 'MODERATOR' ? 'badge-yellow' : 'badge-accent'}`}>
                {user.role}
              </span>
            </div>
          </div>
        </div>

        <hr className="divider" />

        {/* Info */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {[
            { Icon: User, label: 'Username', value: user.username },
            { Icon: Mail, label: 'Email', value: user.email },
            { Icon: Shield, label: 'Role', value: user.role },
          ].map(({ Icon, label, value }) => (
            <div key={label} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <Icon size={15} color="var(--text3)" />
              <span style={{ fontSize: 13, color: 'var(--text3)', width: 80 }}>{label}</span>
              <span style={{ fontSize: 13, color: 'var(--text)' }}>{value}</span>
            </div>
          ))}
        </div>

        <hr className="divider" />

        <button
          className="btn btn-danger btn-sm"
          onClick={() => { logout(); navigate('/login'); }}
        >
          Sign Out
        </button>
      </div>
    </div>
  );
}
