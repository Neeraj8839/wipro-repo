import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { Zap, User, Mail, Lock } from 'lucide-react';
import toast from 'react-hot-toast';

export default function RegisterPage() {
  const { register, loading } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    username: '', email: '', password: '', displayName: '',
  });
  const [error, setError] = useState('');

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');
    if (form.password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }
    const result = await register(form);
    if (result.success) {
      toast.success('Account created! Welcome to DoConnect AI!');
      navigate('/');
    } else {
      setError(result.error);
    }
  };

  const field = (key, label, Icon, type = 'text', placeholder = '') => (
    <div>
      <label style={{ display: 'block', fontSize: 13, color: 'var(--text2)', marginBottom: 6 }}>
        {label}
      </label>
      <div style={{ position: 'relative' }}>
        <Icon size={14} style={{
          position: 'absolute', left: 12, top: '50%',
          transform: 'translateY(-50%)', color: 'var(--text3)', pointerEvents: 'none',
        }} />
        <input
          type={type}
          value={form[key]}
          onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
          placeholder={placeholder}
          style={{ paddingLeft: 36 }}
          required={key !== 'displayName'}
        />
      </div>
    </div>
  );

  return (
    <div style={{
      minHeight: '100vh', display: 'flex',
      alignItems: 'center', justifyContent: 'center',
      background: 'var(--bg)',
      backgroundImage: 'radial-gradient(circle at 80% 20%, rgba(20,184,166,0.07) 0%, transparent 50%)',
      padding: '24px',
    }}>
      <div className="card fade-in" style={{ width: 420, padding: 40 }}>
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div style={{
            width: 52, height: 52, borderRadius: 14,
            background: 'linear-gradient(135deg, var(--teal), var(--accent))',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 12px',
          }}>
            <Zap size={26} color="white" />
          </div>
          <h1 style={{ fontSize: 22, fontWeight: 700, color: 'var(--text)' }}>Join DoConnect AI</h1>
          <p style={{ color: 'var(--text2)', fontSize: 14, marginTop: 4 }}>
            Ask questions, share knowledge, get AI assistance
          </p>
        </div>

        {error && (
          <div style={{
            padding: '10px 14px', borderRadius: 8,
            background: 'var(--red-bg)', color: 'var(--red)',
            border: '1px solid rgba(239,68,68,0.3)', fontSize: 13, marginBottom: 16,
          }}>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {field('displayName', 'Display Name (optional)', User, 'text', 'How you appear to others')}
          {field('username', 'Username *', User, 'text', 'Unique identifier')}
          {field('email', 'Email *', Mail, 'email', 'your@email.com')}
          {field('password', 'Password *', Lock, 'password', 'At least 6 characters')}

          <button type="submit" className="btn btn-primary" disabled={loading}
            style={{ justifyContent: 'center', marginTop: 4 }}>
            {loading ? <span className="spinner" /> : 'Create Account'}
          </button>
        </form>

        <p style={{ textAlign: 'center', marginTop: 24, fontSize: 13, color: 'var(--text2)' }}>
          Already have an account?{' '}
          <Link to="/login" style={{ color: 'var(--accent2)', fontWeight: 500 }}>Sign in</Link>
        </p>
      </div>
    </div>
  );
}
