import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { Zap, Lock, User } from 'lucide-react';
import toast from 'react-hot-toast';

export default function LoginPage() {
  const { login, loading } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ username: '', password: '' });
  const [error, setError] = useState('');

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');
    const result = await login(form);
    if (result.success) {
      toast.success('Welcome back!');
      navigate('/');
    } else {
      setError(result.error);
    }
  };

  return (
    <div style={{
      minHeight: '100vh', display: 'flex',
      alignItems: 'center', justifyContent: 'center',
      background: 'var(--bg)',
      backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(108,99,255,0.08) 0%, transparent 50%)',
    }}>
      <div className="card fade-in" style={{ width: 400, padding: 40 }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div style={{
            width: 52, height: 52, borderRadius: 14,
            background: 'linear-gradient(135deg, var(--accent), var(--teal))',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 12px',
          }}>
            <Zap size={26} color="white" />
          </div>
          <h1 style={{ fontSize: 22, fontWeight: 700, color: 'var(--text)' }}>Welcome back</h1>
          <p style={{ color: 'var(--text2)', fontSize: 14, marginTop: 4 }}>
            Sign in to DoConnect AI
          </p>
        </div>

        {error && (
          <div style={{
            padding: '10px 14px', borderRadius: 8,
            background: 'var(--red-bg)', color: 'var(--red)',
            border: '1px solid rgba(239,68,68,0.3)', fontSize: 13, marginBottom: 16,
          }}>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div>
            <label style={{ display: 'block', fontSize: 13, color: 'var(--text2)', marginBottom: 6 }}>
              Username
            </label>
            <div style={{ position: 'relative' }}>
              <User size={14} style={{
                position: 'absolute', left: 12, top: '50%',
                transform: 'translateY(-50%)', color: 'var(--text3)', pointerEvents: 'none',
              }} />
              <input
                value={form.username}
                onChange={e => setForm(f => ({ ...f, username: e.target.value }))}
                placeholder="Enter username"
                style={{ paddingLeft: 36 }}
                required
              />
            </div>
          </div>

          <div>
            <label style={{ display: 'block', fontSize: 13, color: 'var(--text2)', marginBottom: 6 }}>
              Password
            </label>
            <div style={{ position: 'relative' }}>
              <Lock size={14} style={{
                position: 'absolute', left: 12, top: '50%',
                transform: 'translateY(-50%)', color: 'var(--text3)', pointerEvents: 'none',
              }} />
              <input
                type="password"
                value={form.password}
                onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                placeholder="Enter password"
                style={{ paddingLeft: 36 }}
                required
              />
            </div>
          </div>

          <button type="submit" className="btn btn-primary" disabled={loading}
            style={{ justifyContent: 'center', marginTop: 4 }}>
            {loading ? <span className="spinner" /> : 'Sign In'}
          </button>
        </form>

        <p style={{ textAlign: 'center', marginTop: 24, fontSize: 13, color: 'var(--text2)' }}>
          Don't have an account?{' '}
          <Link to="/register" style={{ color: 'var(--accent2)', fontWeight: 500 }}>
            Sign up free
          </Link>
        </p>

        {/* Demo credentials */}
        <div style={{
          marginTop: 20, padding: 12,
          background: 'var(--bg3)', borderRadius: 8,
          border: '1px solid var(--border)',
        }}>
          <p style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 6 }}>Demo accounts:</p>
          <p style={{ fontSize: 12, color: 'var(--text2)' }}>User: <code style={{ color: 'var(--accent2)' }}>demo / demo123</code></p>
          <p style={{ fontSize: 12, color: 'var(--text2)' }}>Admin: <code style={{ color: 'var(--accent2)' }}>admin / admin123</code></p>
        </div>
      </div>
    </div>
  );
}
