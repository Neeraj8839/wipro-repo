import { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { questionsApi } from '../api';
import { Search, MessageSquare } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import toast from 'react-hot-toast';

export default function SearchPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const query = searchParams.get('q') || '';

  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [searchInput, setSearchInput] = useState(query);

  useEffect(() => {
    if (query) doSearch(query, 0);
  }, [query]);

  const doSearch = async (q, p = 0) => {
    setLoading(true);
    try {
      const res = await questionsApi.search(q, p);
      setResults(res.data.content);
      setTotalPages(res.data.totalPages);
      setPage(p);
    } catch {
      toast.error('Search failed');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = e => {
    e.preventDefault();
    if (searchInput.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchInput)}`);
    }
  };

  return (
    <div style={{ maxWidth: 860, margin: '0 auto', padding: '24px' }}>
      <h1 style={{ fontSize: 20, fontWeight: 700, color: 'var(--text)', marginBottom: 16 }}>
        Search Questions
      </h1>

      {/* Search bar */}
      <form onSubmit={handleSearch} style={{ display: 'flex', gap: 8, marginBottom: 24 }}>
        <div style={{ position: 'relative', flex: 1 }}>
          <Search size={15} style={{
            position: 'absolute', left: 12, top: '50%',
            transform: 'translateY(-50%)', color: 'var(--text3)',
          }} />
          <input
            value={searchInput}
            onChange={e => setSearchInput(e.target.value)}
            placeholder="Search questions, tags, topics..."
            style={{ paddingLeft: 36, height: 42 }}
          />
        </div>
        <button type="submit" className="btn btn-primary">
          <Search size={14} /> Search
        </button>
      </form>

      {/* Results */}
      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', padding: 48 }}>
          <div className="spinner" style={{ width: 32, height: 32 }} />
        </div>
      ) : query && results.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: 48, color: 'var(--text2)' }}>
          <MessageSquare size={40} style={{ opacity: 0.3, marginBottom: 12 }} />
          <p>No results found for "<strong>{query}</strong>"</p>
          <p style={{ fontSize: 13, color: 'var(--text3)', marginTop: 6 }}>
            Try different keywords or browse all questions
          </p>
        </div>
      ) : (
        <>
          {query && (
            <p style={{ fontSize: 13, color: 'var(--text2)', marginBottom: 14 }}>
              {results.length} result{results.length !== 1 ? 's' : ''} for "{query}"
            </p>
          )}
          {results.map(q => (
            <div
              key={q.id}
              className="card fade-in"
              onClick={() => navigate(`/questions/${q.id}`)}
              style={{ cursor: 'pointer', marginBottom: 10, padding: '14px 18px', transition: 'all 0.15s' }}
              onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--accent)'}
              onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}
            >
              <h3 style={{ fontSize: 15, fontWeight: 600, color: 'var(--text)', marginBottom: 6 }}>
                {q.title}
              </h3>
              <p style={{
                fontSize: 13, color: 'var(--text2)', marginBottom: 8,
                overflow: 'hidden', textOverflow: 'ellipsis',
                display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical',
              }}>
                {q.body}
              </p>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                {q.tags?.slice(0, 4).map(t => (
                  <span key={t} className="tag">{t}</span>
                ))}
                <span style={{ marginLeft: 'auto', fontSize: 12, color: 'var(--text3)' }}>
                  {q.voteCount} votes · {q.answerCount} answers ·{' '}
                  {q.createdAt && formatDistanceToNow(new Date(q.createdAt), { addSuffix: true })}
                </span>
              </div>
            </div>
          ))}

          {totalPages > 1 && (
            <div style={{ display: 'flex', gap: 8, justifyContent: 'center', marginTop: 20 }}>
              <button className="btn btn-secondary btn-sm"
                disabled={page === 0} onClick={() => doSearch(query, page - 1)}>
                Previous
              </button>
              <span style={{ padding: '6px 12px', fontSize: 13, color: 'var(--text2)' }}>
                {page + 1} / {totalPages}
              </span>
              <button className="btn btn-secondary btn-sm"
                disabled={page >= totalPages - 1} onClick={() => doSearch(query, page + 1)}>
                Next
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
