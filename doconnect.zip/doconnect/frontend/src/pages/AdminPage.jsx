import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { analyticsApi } from '../api';
import { useAuth } from '../context/AuthContext';
import { Shield, CheckCircle, XCircle, Flag, Zap, RefreshCw } from 'lucide-react';
import toast from 'react-hot-toast';

export default function AdminPage() {
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  const [flagged, setFlagged] = useState([]);
  const [loading, setLoading] = useState(true);
  const [moderateText, setModerateText] = useState('');
  const [moderateResult, setModerateResult] = useState(null);
  const [moderateLoading, setModerateLoading] = useState(false);

  useEffect(() => {
    if (!isAdmin) { navigate('/'); return; }
    loadFlagged();
  }, []);

  const loadFlagged = async () => {
    setLoading(true);
    try {
      const res = await analyticsApi.getFlagged();
      setFlagged(res.data);
    } catch {
      toast.error('Failed to load flagged content');
    } finally {
      setLoading(false);
    }
  };

  const approve = async id => {
    try {
      await analyticsApi.approveQuestion(id);
      setFlagged(f => f.filter(q => q.id !== id));
      toast.success('Approved');
    } catch { toast.error('Failed'); }
  };

  const remove = async id => {
    if (!confirm('Remove this question permanently?')) return;
    try {
      await analyticsApi.removeQuestion(id);
      setFlagged(f => f.filter(q => q.id !== id));
      toast.success('Removed');
    } catch { toast.error('Failed'); }
  };

  const testModeration = async () => {
    if (!moderateText.trim()) return;
    setModerateLoading(true);
    setModerateResult(null);
    try {
      const res = await analyticsApi.moderateContent(moderateText);
      setModerateResult(res.data);
    } catch { toast.error('Moderation test failed'); }
    finally { setModerateLoading(false); }
  };

  if (!isAdmin) return null;

  return (
    <div style={{ maxWidth: 1000, margin: '0 auto', padding: '24px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 24 }}>
        <Shield size={22} color="var(--red)" />
        <h1 style={{ fontSize: 22, fontWeight: 700, color: 'var(--text)' }}>Admin Panel</h1>
        <span className="badge badge-red">ADMIN ONLY</span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        {/* Flagged questions */}
        <div className="card" style={{ padding: '20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
            <Flag size={16} color="var(--red)" />
            <h2 style={{ fontSize: 16, fontWeight: 600, color: 'var(--text)' }}>
              Flagged Questions
            </h2>
            {flagged.length > 0 && <span className="badge badge-red">{flagged.length}</span>}
            <button className="btn btn-ghost btn-sm btn-icon" onClick={loadFlagged} style={{ marginLeft: 'auto' }}>
              <RefreshCw size={14} />
            </button>
          </div>

          {loading ? (
            <div className="spinner" />
          ) : flagged.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '24px 0', color: 'var(--text3)' }}>
              <CheckCircle size={32} style={{ opacity: 0.3, marginBottom: 8 }} />
              <p style={{ fontSize: 13 }}>No flagged content!</p>
            </div>
          ) : (
            flagged.map(q => (
              <div key={q.id} style={{
                padding: '12px',
                background: 'var(--bg3)',
                borderRadius: 8,
                border: '1px solid rgba(239,68,68,0.2)',
                marginBottom: 10,
              }}>
                <p style={{ fontSize: 13, fontWeight: 500, color: 'var(--text)', marginBottom: 4 }}>
                  {q.title}
                </p>
                <p style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 8 }}>
                  Author: {q.author?.username} · {q.status}
                </p>
                {q.moderationNote && (
                  <div style={{
                    fontSize: 11, color: 'var(--yellow)',
                    background: 'var(--yellow-bg)', padding: '4px 8px',
                    borderRadius: 4, marginBottom: 8,
                  }}>
                    AI Note: {q.moderationNote}
                  </div>
                )}
                <div style={{ display: 'flex', gap: 6 }}>
                  <button
                    className="btn btn-sm"
                    onClick={() => approve(q.id)}
                    style={{ background: 'var(--green-bg)', color: 'var(--green)', fontSize: 11 }}
                  >
                    <CheckCircle size={12} /> Approve
                  </button>
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => remove(q.id)}
                    style={{ fontSize: 11 }}
                  >
                    <XCircle size={12} /> Remove
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* AI Moderation Tester */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div className="card" style={{ padding: '20px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
              <Zap size={16} color="var(--accent2)" />
              <h2 style={{ fontSize: 16, fontWeight: 600, color: 'var(--text)' }}>
                AI Moderation Tester
              </h2>
            </div>
            <p style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 12 }}>
              Test the AI content moderation engine on any text
            </p>
            <textarea
              value={moderateText}
              onChange={e => setModerateText(e.target.value)}
              placeholder="Enter text to analyze for toxicity or spam..."
              rows={5}
              style={{ resize: 'vertical', marginBottom: 10, fontSize: 13 }}
            />
            <button
              className="btn btn-primary btn-sm"
              onClick={testModeration}
              disabled={moderateLoading || !moderateText.trim()}
            >
              {moderateLoading
                ? <><span className="spinner" style={{ width: 12, height: 12 }} /> Analyzing...</>
                : <><Zap size={13} /> Run AI Moderation</>
              }
            </button>

            {moderateResult && (
              <div style={{
                marginTop: 14, padding: '12px',
                background: moderateResult.isToxic || moderateResult.isSpam
                  ? 'var(--red-bg)' : 'var(--green-bg)',
                borderRadius: 8,
                border: `1px solid ${moderateResult.isToxic || moderateResult.isSpam ? 'rgba(239,68,68,0.3)' : 'rgba(34,197,94,0.3)'}`,
              }}>
                <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', marginBottom: 8 }}>
                  <div>
                    <span style={{ fontSize: 11, color: 'var(--text3)' }}>Toxic</span>
                    <div style={{ fontSize: 14, fontWeight: 600, color: moderateResult.isToxic ? 'var(--red)' : 'var(--green)' }}>
                      {moderateResult.isToxic ? 'YES' : 'NO'}
                    </div>
                  </div>
                  <div>
                    <span style={{ fontSize: 11, color: 'var(--text3)' }}>Spam</span>
                    <div style={{ fontSize: 14, fontWeight: 600, color: moderateResult.isSpam ? 'var(--red)' : 'var(--green)' }}>
                      {moderateResult.isSpam ? 'YES' : 'NO'}
                    </div>
                  </div>
                  <div>
                    <span style={{ fontSize: 11, color: 'var(--text3)' }}>Confidence</span>
                    <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)' }}>
                      {(moderateResult.confidence * 100).toFixed(0)}%
                    </div>
                  </div>
                </div>
                {moderateResult.reason && (
                  <p style={{ fontSize: 12, color: 'var(--text2)' }}>
                    Reason: {moderateResult.reason}
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Info */}
          <div className="card" style={{
            padding: '18px',
            background: 'rgba(108,99,255,0.06)',
            borderColor: 'rgba(108,99,255,0.2)',
          }}>
            <h3 style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)', marginBottom: 10 }}>
              AI Moderation Engine
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {[
                { label: 'Toxic detection', status: 'Active', color: 'var(--green)' },
                { label: 'Spam filtering', status: 'Active', color: 'var(--green)' },
                { label: 'Auto-flag', status: 'Active', color: 'var(--green)' },
                { label: 'AI alerts', status: 'Active', color: 'var(--green)' },
              ].map(item => (
                <div key={item.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: 13, color: 'var(--text2)' }}>{item.label}</span>
                  <span style={{ fontSize: 11, fontWeight: 600, color: item.color }}>● {item.status}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
