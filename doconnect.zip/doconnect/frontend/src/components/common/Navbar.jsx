import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { Search, Bell, LogOut, User, Shield, BarChart2, MessageSquare, Home, Zap } from 'lucide-react';

export default function Navbar() {
  const { user, logout, isAdmin, isModerator } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [searchQ, setSearchQ] = useState('');

  const handleSearch = e => {
    e.preventDefault();
    if (searchQ.trim()) navigate(`/search?q=${encodeURIComponent(searchQ)}`);
  };

  const handleLogout = () => { logout(); navigate('/login'); };

  const navLink = (path, label, Icon) => (
    <Link
      to={path}
      style={{
        display: 'flex', alignItems: 'center', gap: 6,
        padding: '6px 12px', borderRadius: 8,
        fontSize: 14, fontWeight: 500,
        color: location.pathname === path ? 'var(--accent2)' : 'var(--text2)',
        background: location.pathname === path ? 'var(--accent-bg)' : 'transparent',
        transition: 'all 0.15s',
      }}
    >
      <Icon size={16} /> {label}
    </Link>
  );

  return (
    <nav style={{
      background: 'var(--bg2)',
      borderBottom: '1px solid var(--border)',
      padding: '0 24px',
      height: 60,
      display: 'flex', alignItems: 'center', gap: 16,
      position: 'sticky', top: 0, zIndex: 100,
    }}>
      {/* Logo */}
      <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: 8, marginRight: 8 }}>
        <div style={{
          width: 32, height: 32, borderRadius: 8,
          background: 'linear-gradient(135deg, var(--accent), var(--teal))',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Zap size={18} color="white" />
        </div>
        <span style={{ fontWeight: 700, fontSize: 16, color: 'var(--text)' }}>DoConnect</span>
        <span style={{
          fontSize: 10, fontWeight: 600, padding: '1px 6px',
          borderRadius: 4, background: 'var(--accent-bg)',
          color: 'var(--accent2)', letterSpacing: '0.05em',
        }}>AI</span>
      </Link>

      {/* Nav links */}
      <div style={{ display: 'flex', gap: 4, flex: 1 }}>
        {navLink('/', 'Home', Home)}
        {navLink('/questions', 'Questions', MessageSquare)}
        {navLink('/chat', 'Chat', MessageSquare)}
        {isModerator && navLink('/dashboard', 'Dashboard', BarChart2)}
        {isAdmin && navLink('/admin', 'Admin', Shield)}
      </div>

      {/* Search */}
      <form onSubmit={handleSearch} style={{ display: 'flex', alignItems: 'center' }}>
        <div style={{ position: 'relative' }}>
          <Search size={14} style={{
            position: 'absolute', left: 10, top: '50%',
            transform: 'translateY(-50%)', color: 'var(--text3)',
          }} />
          <input
            value={searchQ}
            onChange={e => setSearchQ(e.target.value)}
            placeholder="Search questions..."
            style={{ paddingLeft: 32, width: 220, height: 36, fontSize: 13 }}
          />
        </div>
      </form>

      {/* User area */}
      {user ? (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Link to="/profile" className="btn btn-ghost btn-sm"
            style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{
              width: 28, height: 28, borderRadius: '50%',
              background: 'var(--accent)', display: 'flex',
              alignItems: 'center', justifyContent: 'center',
              fontSize: 12, fontWeight: 600, color: 'white',
            }}>
              {user.displayName?.[0]?.toUpperCase() || user.username[0].toUpperCase()}
            </div>
            <span style={{ fontSize: 13 }}>{user.displayName || user.username}</span>
            {isModerator && (
              <span className="badge badge-accent" style={{ fontSize: 10 }}>
                {isAdmin ? 'ADMIN' : 'MOD'}
              </span>
            )}
          </Link>
          <button onClick={handleLogout} className="btn btn-ghost btn-icon">
            <LogOut size={15} />
          </button>
        </div>
      ) : (
        <div style={{ display: 'flex', gap: 8 }}>
          <Link to="/login" className="btn btn-secondary btn-sm">Log in</Link>
          <Link to="/register" className="btn btn-primary btn-sm">Sign up</Link>
        </div>
      )}
    </nav>
  );
}
