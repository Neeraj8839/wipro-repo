import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export function ProtectedRoute({ children, requireAdmin = false, requireModerator = false }) {
  const { user, isAdmin, isModerator } = useAuth();

  if (!user) return <Navigate to="/login" replace />;
  if (requireAdmin && !isAdmin) return <Navigate to="/" replace />;
  if (requireModerator && !isModerator) return <Navigate to="/" replace />;

  return children;
}
