import { useEffect, useRef, useState, useCallback } from 'react';
import { Client } from '@stomp/stompjs';
import SockJS from 'sockjs-client';

export function useWebSocket(roomId, onMessage) {
  const [connected, setConnected] = useState(false);
  const clientRef = useRef(null);

  useEffect(() => {
    if (!roomId) return;

    const client = new Client({
      webSocketFactory: () => new SockJS('/ws'),
      reconnectDelay: 3000,
      onConnect: () => {
        setConnected(true);
        client.subscribe(`/topic/chat/${roomId}`, msg => {
          try {
            const data = JSON.parse(msg.body);
            onMessage(data);
          } catch (e) {
            console.error('WebSocket message parse error', e);
          }
        });
      },
      onDisconnect: () => setConnected(false),
      onStompError: frame => {
        console.error('STOMP error:', frame);
        setConnected(false);
      },
    });

    client.activate();
    clientRef.current = client;

    return () => {
      client.deactivate();
    };
  }, [roomId]);

  const sendMessage = useCallback((content, username, type = 'CHAT') => {
    if (clientRef.current?.connected) {
      clientRef.current.publish({
        destination: `/app/chat/${roomId}`,
        body: JSON.stringify({ content, username, type }),
      });
    }
  }, [roomId]);

  return { connected, sendMessage };
}
