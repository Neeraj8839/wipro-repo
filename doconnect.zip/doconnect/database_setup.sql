-- DoConnect AI – MySQL Database Setup Script
-- Run this before starting the Spring Boot application

CREATE DATABASE IF NOT EXISTS doconnect_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE doconnect_db;

-- The tables below are auto-created by Hibernate (spring.jpa.hibernate.ddl-auto=update)
-- This script creates demo/seed data for testing

-- After starting the app once (tables auto-created), run the INSERT statements below:

-- Demo Users (passwords are BCrypt hashed; plain text shown in comments)
-- To generate BCrypt hash in Java: new BCryptPasswordEncoder().encode("password")
-- We'll insert them via the app's /api/auth/register endpoint instead.

-- ============================================================
-- OPTIONAL: Seed data script (run after app starts and creates tables)
-- ============================================================

-- Demo admin user (run via register API or manually insert):
-- POST /api/auth/register
-- { "username": "admin", "email": "admin@doconnect.ai", "password": "admin123", "displayName": "Admin" }
-- Then UPDATE users SET role = 'ADMIN' WHERE username = 'admin';

-- Demo moderator:
-- POST /api/auth/register
-- { "username": "moderator", "email": "mod@doconnect.ai", "password": "mod123", "displayName": "Moderator" }
-- Then UPDATE users SET role = 'MODERATOR' WHERE username = 'moderator';

-- Demo user:
-- POST /api/auth/register
-- { "username": "demo", "email": "demo@doconnect.ai", "password": "demo123", "displayName": "Demo User" }

-- ============================================================
-- Verify tables after app startup:
-- ============================================================
-- SHOW TABLES;
-- DESCRIBE users;
-- DESCRIBE questions;
-- DESCRIBE answers;
-- DESCRIBE chat_messages;
-- DESCRIBE notifications;
-- DESCRIBE question_tags;

SELECT 'Database setup complete. Start the Spring Boot app to auto-create tables.' AS message;
