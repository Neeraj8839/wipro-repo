package com.doconnect.dto;

import com.doconnect.entity.Question;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class QuestionDto {

    @Data
    public static class CreateRequest {
        @NotBlank
        @Size(min = 10, max = 300)
        private String title;

        @NotBlank
        @Size(min = 20)
        private String body;

        private List<String> tags;
    }

    @Data
    public static class Response {
        private Long id;
        private String title;
        private String body;
        private List<String> tags;
        private String authorName;
        private Long authorId;
        private Integer viewCount;
        private Integer voteCount;
        private Boolean isSolved;
        private Integer answerCount;
        private LocalDateTime createdAt;
        private Question.QuestionStatus status;

        public static Response from(Question q) {
            Response r = new Response();
            r.id = q.getId();
            r.title = q.getTitle();
            r.body = q.getBody();
            r.tags = q.getTags();
            r.authorName = q.getAuthor().getDisplayName() != null ?
                q.getAuthor().getDisplayName() : q.getAuthor().getUsername();
            r.authorId = q.getAuthor().getId();
            r.viewCount = q.getViewCount();
            r.voteCount = q.getVoteCount();
            r.isSolved = q.getIsSolved();
            r.answerCount = q.getAnswers().size();
            r.createdAt = q.getCreatedAt();
            r.status = q.getStatus();
            return r;
        }
    }
}
