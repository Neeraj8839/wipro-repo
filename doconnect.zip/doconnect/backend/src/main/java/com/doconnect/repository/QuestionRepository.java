package com.doconnect.repository;

import com.doconnect.entity.Question;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface QuestionRepository extends JpaRepository<Question, Long> {

    Page<Question> findByStatusOrderByCreatedAtDesc(Question.QuestionStatus status, Pageable pageable);

    @Query("SELECT q FROM Question q WHERE LOWER(q.title) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
           "OR LOWER(q.body) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    Page<Question> searchByKeyword(@Param("keyword") String keyword, Pageable pageable);

    @Query("SELECT q FROM Question q JOIN q.tags t WHERE t IN :tags AND q.id != :excludeId ORDER BY q.voteCount DESC")
    List<Question> findSimilarByTags(@Param("tags") List<String> tags,
                                     @Param("excludeId") Long excludeId,
                                     Pageable pageable);

    @Query("SELECT t, COUNT(t) as cnt FROM Question q JOIN q.tags t GROUP BY t ORDER BY cnt DESC")
    List<Object[]> findTrendingTags(Pageable pageable);

    Page<Question> findByAuthorId(Long authorId, Pageable pageable);

    @Modifying
    @Query("UPDATE Question q SET q.viewCount = q.viewCount + 1 WHERE q.id = :id")
    void incrementViewCount(@Param("id") Long id);

    @Query("SELECT q FROM Question q WHERE q.status = 'FLAGGED'")
    List<Question> findFlaggedQuestions();

    @Query("SELECT COUNT(q) FROM Question q WHERE q.createdAt >= CURRENT_DATE")
    long countQuestionsToday();
}
