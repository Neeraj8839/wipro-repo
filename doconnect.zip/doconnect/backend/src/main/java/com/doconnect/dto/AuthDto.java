package com.doconnect.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

public class AuthDto {

    @Data
    public static class RegisterRequest {
        @NotBlank
        @Size(min = 3, max = 50)
        private String username;

        @Email
        @NotBlank
        private String email;

        @NotBlank
        @Size(min = 6, max = 100)
        private String password;

        private String displayName;
    }

    @Data
    public static class LoginRequest {
        @NotBlank
        private String username;

        @NotBlank
        private String password;
    }

    @Data
    public static class AuthResponse {
        private String token;
        private String username;
        private String email;
        private String displayName;
        private String role;
        private Long userId;

        public static AuthResponse of(String token, com.doconnect.entity.User user) {
            AuthResponse resp = new AuthResponse();
            resp.token = token;
            resp.username = user.getUsername();
            resp.email = user.getEmail();
            resp.displayName = user.getDisplayName() != null ? user.getDisplayName() : user.getUsername();
            resp.role = user.getRole().name();
            resp.userId = user.getId();
            return resp;
        }
    }
}
