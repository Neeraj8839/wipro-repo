package com.doconnect.dto;

import com.doconnect.entity.Answer;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AnswerDto {

    @Data
    public static class CreateRequest {
        @NotBlank
        @Size(min = 10)
        private String body;
    }

    @Data
    public static class Response {
        private Long id;
        private String body;
        private Long questionId;
        private String authorName;
        private Long authorId;
        private Boolean isAiGenerated;
        private Boolean isAccepted;
        private Integer voteCount;
        private LocalDateTime createdAt;

        public static Response from(Answer a) {
            Response r = new Response();
            r.id = a.getId();
            r.body = a.getBody();
            r.questionId = a.getQuestion().getId();
            if (a.getAuthor() != null) {
                r.authorName = a.getAuthor().getDisplayName() != null ?
                    a.getAuthor().getDisplayName() : a.getAuthor().getUsername();
                r.authorId = a.getAuthor().getId();
            } else {
                r.authorName = "DoConnect AI";
            }
            r.isAiGenerated = a.getIsAiGenerated();
            r.isAccepted = a.getIsAccepted();
            r.voteCount = a.getVoteCount();
            r.createdAt = a.getCreatedAt();
            return r;
        }
    }
}
