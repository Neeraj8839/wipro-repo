package com.doconnect.service;

import com.doconnect.repository.AnswerRepository;
import com.doconnect.repository.QuestionRepository;
import com.doconnect.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AnalyticsService {

    private final QuestionRepository questionRepository;
    private final AnswerRepository answerRepository;
    private final UserRepository userRepository;

    public Map<String, Object> getDashboardStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalQuestions", questionRepository.count());
        stats.put("totalAnswers", answerRepository.count());
        stats.put("totalUsers", userRepository.count());
        stats.put("questionsToday", questionRepository.countQuestionsToday());
        stats.put("newUsersToday", userRepository.countNewUsersToday());
        stats.put("moderatedAnswers", answerRepository.countModeratedAnswers());

        // Trending tags
        List<Map<String, Object>> trendingTags = questionRepository
            .findTrendingTags(PageRequest.of(0, 10))
            .stream()
            .map(row -> {
                Map<String, Object> tagMap = new HashMap<>();
                tagMap.put("tag", row[0]);
                tagMap.put("count", row[1]);
                return tagMap;
            })
            .collect(Collectors.toList());
        stats.put("trendingTags", trendingTags);

        // Top users
        stats.put("topUsers", userRepository.findTopUsersByReputation().stream()
            .map(u -> Map.of(
                "username", u.getUsername(),
                "displayName", u.getDisplayName() != null ? u.getDisplayName() : u.getUsername(),
                "reputation", u.getReputation()
            )).collect(Collectors.toList()));

        // Flagged content for moderators
        stats.put("flaggedQuestions", questionRepository.findFlaggedQuestions().size());

        return stats;
    }
}
