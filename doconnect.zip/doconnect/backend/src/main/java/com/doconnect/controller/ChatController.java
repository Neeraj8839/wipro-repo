package com.doconnect.controller;

import com.doconnect.dto.ChatMessageDto;
import com.doconnect.entity.ChatMessage;
import com.doconnect.service.ChatService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
@RequiredArgsConstructor
public class ChatController {

    private final ChatService chatService;

    /**
     * WebSocket endpoint: /app/chat/{roomId}
     * Clients subscribe to: /topic/chat/{roomId}
     */
    @MessageMapping("/chat/{roomId}")
    public void handleChatMessage(@DestinationVariable String roomId,
                                   @Payload Map<String, String> payload) {
        String content = payload.get("content");
        String username = payload.get("username");
        String typeStr = payload.getOrDefault("type", "CHAT");
        ChatMessage.MessageType type;
        try {
            type = ChatMessage.MessageType.valueOf(typeStr);
        } catch (Exception e) {
            type = ChatMessage.MessageType.CHAT;
        }
        chatService.sendMessage(roomId, content, username, type);
    }

    @RestController
    @RequestMapping("/api/chat")
    @RequiredArgsConstructor
    static class ChatRestController {
        private final ChatService chatService;

        @GetMapping("/{roomId}/history")
        public ResponseEntity<List<ChatMessageDto>> getHistory(
                @PathVariable String roomId,
                @RequestParam(defaultValue = "50") int limit) {
            return ResponseEntity.ok(chatService.getRoomHistory(roomId, limit));
        }

        @GetMapping("/rooms")
        public ResponseEntity<List<String>> getRooms() {
            return ResponseEntity.ok(chatService.getAvailableRooms());
        }
    }
}
