package com.doconnect.service;

import com.doconnect.dto.ChatMessageDto;
import com.doconnect.entity.ChatMessage;
import com.doconnect.entity.User;
import com.doconnect.repository.ChatMessageRepository;
import com.doconnect.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ChatService {

    private final ChatMessageRepository chatMessageRepository;
    private final UserRepository userRepository;
    private final SimpMessagingTemplate messagingTemplate;
    private final AnthropicAIService aiService;

    @Transactional
    public ChatMessageDto sendMessage(String roomId, String content,
                                      String username, ChatMessage.MessageType type) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        User sender = userOpt.orElse(null);

        // Moderate incoming message
        if (type == ChatMessage.MessageType.CHAT && content != null) {
            AnthropicAIService.ModerationResult mod = aiService.moderateContent(content);
            if (mod.isToxic() || mod.isSpam()) {
                // Send system alert to room
                broadcastSystem(roomId, "A message was removed by AI moderation.");
                return null;
            }
        }

        ChatMessage message = ChatMessage.builder()
            .roomId(roomId)
            .content(content)
            .sender(sender)
            .senderName(sender != null ?
                (sender.getDisplayName() != null ? sender.getDisplayName() : sender.getUsername())
                : username)
            .type(type)
            .isModerated(false)
            .build();

        ChatMessage saved = chatMessageRepository.save(message);
        ChatMessageDto dto = ChatMessageDto.from(saved);

        // Broadcast to all subscribers of this room
        messagingTemplate.convertAndSend("/topic/chat/" + roomId, dto);

        return dto;
    }

    public void broadcastSystem(String roomId, String message) {
        ChatMessageDto sysMsg = new ChatMessageDto();
        sysMsg.setRoomId(roomId);
        sysMsg.setContent(message);
        sysMsg.setSenderName("System");
        sysMsg.setType(ChatMessage.MessageType.SYSTEM);
        messagingTemplate.convertAndSend("/topic/chat/" + roomId, sysMsg);
    }

    public List<ChatMessageDto> getRoomHistory(String roomId, int limit) {
        return chatMessageRepository
            .findByRoomIdOrderByCreatedAtAsc(roomId, PageRequest.of(0, limit))
            .stream().map(ChatMessageDto::from).collect(Collectors.toList());
    }

    public List<String> getAvailableRooms() {
        return List.of("general", "java", "python", "javascript", "spring-boot",
                       "react", "database", "devops", "ai-ml", "help");
    }
}
