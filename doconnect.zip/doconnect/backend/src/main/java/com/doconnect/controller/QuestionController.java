package com.doconnect.controller;

import com.doconnect.dto.QuestionDto;
import com.doconnect.service.QuestionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/questions")
@RequiredArgsConstructor
public class QuestionController {

    private final QuestionService questionService;

    @PostMapping
    public ResponseEntity<QuestionDto.Response> create(
            @Valid @RequestBody QuestionDto.CreateRequest req,
            @AuthenticationPrincipal UserDetails user) {
        return ResponseEntity.ok(questionService.create(req, user.getUsername()));
    }

    @GetMapping
    public ResponseEntity<Page<QuestionDto.Response>> getAll(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "latest") String sort) {
        return ResponseEntity.ok(questionService.getAll(page, size, sort));
    }

    @GetMapping("/{id}")
    public ResponseEntity<QuestionDto.Response> getById(@PathVariable Long id) {
        return ResponseEntity.ok(questionService.getById(id));
    }

    @GetMapping("/search")
    public ResponseEntity<Page<QuestionDto.Response>> search(
            @RequestParam String q,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(questionService.search(q, page, size));
    }

    @GetMapping("/{id}/similar")
    public ResponseEntity<List<QuestionDto.Response>> getSimilar(@PathVariable Long id) {
        return ResponseEntity.ok(questionService.getSimilar(id));
    }

    @PostMapping("/{id}/vote")
    public ResponseEntity<QuestionDto.Response> vote(
            @PathVariable Long id,
            @RequestParam int delta,
            @AuthenticationPrincipal UserDetails user) {
        return ResponseEntity.ok(questionService.vote(id, delta, user.getUsername()));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails user) {
        questionService.delete(id, user.getUsername());
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/trending-tags")
    public ResponseEntity<List<String[]>> getTrendingTags(
            @RequestParam(defaultValue = "10") int limit) {
        return ResponseEntity.ok(questionService.getTrendingTags(limit));
    }
}
