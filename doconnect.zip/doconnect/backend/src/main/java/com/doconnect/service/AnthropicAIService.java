package com.doconnect.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor
public class AnthropicAIService {

    @Value("${anthropic.api.key}")
    private String apiKey;

    @Value("${anthropic.model}")
    private String model;

    private final WebClient.Builder webClientBuilder;

    private WebClient getClient() {
        return webClientBuilder
            .baseUrl("https://api.anthropic.com")
            .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .defaultHeader("x-api-key", apiKey)
            .defaultHeader("anthropic-version", "2023-06-01")
            .build();
    }

    /**
     * Module 3: Generate AI answer for a question
     */
    public String generateAnswer(String questionTitle, String questionBody, List<String> tags) {
        String prompt = String.format("""
            You are a helpful technical assistant on a Q&A platform (like StackOverflow).
            
            Question Title: %s
            Question Body: %s
            Tags: %s
            
            Please provide a clear, concise, and accurate answer. Use code examples if relevant.
            Format your response in markdown. Be helpful and educational.
            """, questionTitle, questionBody, String.join(", ", tags));

        return callAI(prompt, 1500);
    }

    /**
     * Module 2: Predict smart tags for a question
     */
    public List<String> predictTags(String title, String body) {
        String prompt = String.format("""
            Analyze the following question and suggest 3-5 relevant technical tags.
            
            Title: %s
            Body: %s
            
            Respond with ONLY a comma-separated list of lowercase tags. Example: java,spring-boot,jwt
            No explanation, no extra text — just the tags.
            """, title, body);

        String result = callAI(prompt, 100);
        return List.of(result.trim().split(",\\s*"));
    }

    /**
     * Module 3: Auto-summarize a long question or answer
     */
    public String summarize(String text) {
        String prompt = String.format("""
            Summarize the following technical content in 2-3 concise sentences.
            Keep it informative and accurate. Respond with just the summary.
            
            Content: %s
            """, text);

        return callAI(prompt, 300);
    }

    /**
     * Module 3: Grammar enhancement
     */
    public String enhanceGrammar(String text) {
        String prompt = String.format("""
            Improve the grammar, clarity, and readability of the following text.
            Keep the technical meaning intact. Respond with only the improved text.
            
            Text: %s
            """, text);

        return callAI(prompt, 1000);
    }

    /**
     * Module 5: Content moderation — detect toxic or spam content
     */
    public ModerationResult moderateContent(String content) {
        String prompt = String.format("""
            Analyze the following content for moderation on a technical Q&A platform.
            Check for: toxic language, harassment, spam, hate speech, irrelevant content.
            
            Content: %s
            
            Respond ONLY in this exact JSON format (no markdown, no extra text):
            {"isToxic": true/false, "isSpam": true/false, "confidence": 0.0-1.0, "reason": "brief reason or empty string"}
            """, content);

        String result = callAI(prompt, 200);
        return parseModerationResult(result);
    }

    /**
     * Module 6: Sentiment analysis for analytics dashboard
     */
    public String analyzeSentiment(String text) {
        String prompt = String.format("""
            Analyze the sentiment of the following text.
            Respond with ONLY one word: POSITIVE, NEGATIVE, or NEUTRAL
            
            Text: %s
            """, text);

        return callAI(prompt, 20).trim().toUpperCase();
    }

    /**
     * Module 2: Find similar question recommendations
     */
    public List<String> extractKeywords(String title, String body) {
        String prompt = String.format("""
            Extract the 5 most important technical keywords from this question.
            Respond with ONLY a comma-separated list. Example: java,null pointer,exception,runtime
            
            Title: %s
            Body: %s
            """, title, body);

        String result = callAI(prompt, 100);
        return List.of(result.trim().split(",\\s*"));
    }

    private String callAI(String prompt, int maxTokens) {
        try {
            Map<String, Object> requestBody = Map.of(
                "model", model,
                "max_tokens", maxTokens,
                "messages", List.of(
                    Map.of("role", "user", "content", prompt)
                )
            );

            Map response = getClient()
                .post()
                .uri("/v1/messages")
                .bodyValue(requestBody)
                .retrieve()
                .bodyToMono(Map.class)
                .block();

            if (response != null && response.containsKey("content")) {
                List<Map> content = (List<Map>) response.get("content");
                if (!content.isEmpty()) {
                    return (String) content.get(0).get("text");
                }
            }
        } catch (Exception e) {
            log.error("AI API call failed: {}", e.getMessage());
        }
        return "AI service temporarily unavailable.";
    }

    private ModerationResult parseModerationResult(String json) {
        try {
            // Simple JSON parsing without full deserialization
            boolean isToxic = json.contains("\"isToxic\":true") || json.contains("\"isToxic\": true");
            boolean isSpam = json.contains("\"isSpam\":true") || json.contains("\"isSpam\": true");
            double confidence = 0.5;
            String reasonStr = "";

            // Extract confidence
            if (json.contains("\"confidence\":")) {
                int idx = json.indexOf("\"confidence\":") + 13;
                int end = json.indexOf(",", idx);
                if (end == -1) end = json.indexOf("}", idx);
                try {
                    confidence = Double.parseDouble(json.substring(idx, end).trim());
                } catch (Exception ignored) {}
            }

            // Extract reason
            if (json.contains("\"reason\":\"")) {
                int idx = json.indexOf("\"reason\":\"") + 10;
                int end = json.indexOf("\"", idx);
                if (end > idx) reasonStr = json.substring(idx, end);
            }

            return new ModerationResult(isToxic, isSpam, confidence, reasonStr);
        } catch (Exception e) {
            return new ModerationResult(false, false, 0.0, "");
        }
    }

    public record ModerationResult(
        boolean isToxic,
        boolean isSpam,
        double confidence,
        String reason
    ) {}
}
