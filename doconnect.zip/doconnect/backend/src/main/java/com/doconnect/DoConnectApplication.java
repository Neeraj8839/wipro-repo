package com.doconnect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class DoConnectApplication {
    public static void main(String[] args) {
        SpringApplication.run(DoConnectApplication.class, args);
    }
}
