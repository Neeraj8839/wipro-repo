package com.doconnect.controller;

import com.doconnect.dto.AnswerDto;
import com.doconnect.service.AnswerService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class AnswerController {

    private final AnswerService answerService;

    @PostMapping("/questions/{questionId}/answers")
    public ResponseEntity<AnswerDto.Response> create(
            @PathVariable Long questionId,
            @Valid @RequestBody AnswerDto.CreateRequest req,
            @AuthenticationPrincipal UserDetails user) {
        return ResponseEntity.ok(answerService.create(questionId, req, user.getUsername()));
    }

    @PostMapping("/questions/{questionId}/answers/ai")
    public ResponseEntity<AnswerDto.Response> generateAi(@PathVariable Long questionId) {
        return ResponseEntity.ok(answerService.generateAiAnswer(questionId));
    }

    @GetMapping("/questions/{questionId}/answers")
    public ResponseEntity<List<AnswerDto.Response>> getByQuestion(@PathVariable Long questionId) {
        return ResponseEntity.ok(answerService.getByQuestion(questionId));
    }

    @PostMapping("/answers/{id}/accept")
    public ResponseEntity<AnswerDto.Response> accept(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails user) {
        return ResponseEntity.ok(answerService.accept(id, user.getUsername()));
    }

    @PostMapping("/answers/{id}/vote")
    public ResponseEntity<AnswerDto.Response> vote(
            @PathVariable Long id,
            @RequestParam int delta) {
        return ResponseEntity.ok(answerService.vote(id, delta));
    }

    @GetMapping("/answers/{id}/summarize")
    public ResponseEntity<Map<String, String>> summarize(@PathVariable Long id) {
        return ResponseEntity.ok(Map.of("summary", answerService.summarize(id)));
    }

    @PostMapping("/ai/enhance-grammar")
    public ResponseEntity<Map<String, String>> enhanceGrammar(@RequestBody Map<String, String> body) {
        return ResponseEntity.ok(Map.of("enhanced", answerService.enhanceGrammar(body.get("text"))));
    }
}
