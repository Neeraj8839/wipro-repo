package com.doconnect.service;

import com.doconnect.dto.QuestionDto;
import com.doconnect.entity.Question;
import com.doconnect.entity.User;
import com.doconnect.repository.QuestionRepository;
import com.doconnect.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class QuestionService {

    private final QuestionRepository questionRepository;
    private final UserRepository userRepository;
    private final AnthropicAIService aiService;

    @Transactional
    public QuestionDto.Response create(QuestionDto.CreateRequest req, String username) {
        User author = userRepository.findByUsername(username)
            .orElseThrow(() -> new EntityNotFoundException("User not found"));

        // AI-powered tag prediction if no tags provided
        List<String> tags = req.getTags();
        if (tags == null || tags.isEmpty()) {
            try {
                tags = aiService.predictTags(req.getTitle(), req.getBody());
            } catch (Exception e) {
                tags = List.of();
            }
        }

        // AI content moderation
        AnthropicAIService.ModerationResult modResult =
            aiService.moderateContent(req.getTitle() + " " + req.getBody());

        Question question = Question.builder()
            .title(req.getTitle())
            .body(req.getBody())
            .tags(tags)
            .author(author)
            .viewCount(0)
            .voteCount(0)
            .isSolved(false)
            .isModerated(modResult.isToxic() || modResult.isSpam())
            .moderationNote(modResult.reason())
            .status(modResult.isToxic() || modResult.isSpam()
                ? Question.QuestionStatus.FLAGGED
                : Question.QuestionStatus.OPEN)
            .build();

        return QuestionDto.Response.from(questionRepository.save(question));
    }

    public Page<QuestionDto.Response> getAll(int page, int size, String sort) {
        Sort sortObj = sort.equals("votes") ?
            Sort.by(Sort.Direction.DESC, "voteCount") :
            Sort.by(Sort.Direction.DESC, "createdAt");
        Pageable pageable = PageRequest.of(page, size, sortObj);
        return questionRepository
            .findByStatusOrderByCreatedAtDesc(Question.QuestionStatus.OPEN, pageable)
            .map(QuestionDto.Response::from);
    }

    @Transactional
    public QuestionDto.Response getById(Long id) {
        questionRepository.incrementViewCount(id);
        Question q = questionRepository.findById(id)
            .orElseThrow(() -> new EntityNotFoundException("Question not found"));
        return QuestionDto.Response.from(q);
    }

    public Page<QuestionDto.Response> search(String keyword, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return questionRepository.searchByKeyword(keyword, pageable)
            .map(QuestionDto.Response::from);
    }

    public List<QuestionDto.Response> getSimilar(Long questionId) {
        Question q = questionRepository.findById(questionId)
            .orElseThrow(() -> new EntityNotFoundException("Question not found"));
        Pageable top5 = PageRequest.of(0, 5);
        return questionRepository.findSimilarByTags(q.getTags(), questionId, top5)
            .stream().map(QuestionDto.Response::from).collect(Collectors.toList());
    }

    @Transactional
    public QuestionDto.Response vote(Long id, int delta, String username) {
        Question q = questionRepository.findById(id)
            .orElseThrow(() -> new EntityNotFoundException("Question not found"));
        q.setVoteCount(q.getVoteCount() + delta);
        return QuestionDto.Response.from(questionRepository.save(q));
    }

    @Transactional
    public void delete(Long id, String username) {
        Question q = questionRepository.findById(id)
            .orElseThrow(() -> new EntityNotFoundException("Question not found"));
        User user = userRepository.findByUsername(username)
            .orElseThrow(() -> new EntityNotFoundException("User not found"));
        if (!q.getAuthor().getId().equals(user.getId()) &&
            !user.getRole().name().equals("ADMIN")) {
            throw new AccessDeniedException("Not authorized");
        }
        questionRepository.delete(q);
    }

    public List<String[]> getTrendingTags(int limit) {
        Pageable top = PageRequest.of(0, limit);
        return questionRepository.findTrendingTags(top).stream()
            .map(row -> new String[]{(String) row[0], row[1].toString()})
            .collect(Collectors.toList());
    }
}
