package com.doconnect.enums;

public enum Role {
    USER,
    MODERATOR,
    ADMIN
}
