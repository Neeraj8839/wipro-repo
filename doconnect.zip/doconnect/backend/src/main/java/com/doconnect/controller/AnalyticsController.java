package com.doconnect.controller;

import com.doconnect.entity.Question;
import com.doconnect.repository.QuestionRepository;
import com.doconnect.service.AnalyticsService;
import com.doconnect.service.AnthropicAIService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class AnalyticsController {

    private final AnalyticsService analyticsService;
    private final AnthropicAIService aiService;
    private final QuestionRepository questionRepository;

    @GetMapping("/analytics/dashboard")
    @PreAuthorize("hasAnyRole('ADMIN', 'MODERATOR')")
    public ResponseEntity<Map<String, Object>> getDashboard() {
        return ResponseEntity.ok(analyticsService.getDashboardStats());
    }

    @GetMapping("/moderation/flagged")
    @PreAuthorize("hasAnyRole('ADMIN', 'MODERATOR')")
    public ResponseEntity<List<Question>> getFlagged() {
        return ResponseEntity.ok(questionRepository.findFlaggedQuestions());
    }

    @PostMapping("/moderation/questions/{id}/approve")
    @PreAuthorize("hasAnyRole('ADMIN', 'MODERATOR')")
    public ResponseEntity<Void> approveQuestion(@PathVariable Long id) {
        Question q = questionRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Question not found"));
        q.setStatus(Question.QuestionStatus.OPEN);
        q.setIsModerated(false);
        questionRepository.save(q);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/moderation/questions/{id}/remove")
    @PreAuthorize("hasAnyRole('ADMIN', 'MODERATOR')")
    public ResponseEntity<Void> removeQuestion(@PathVariable Long id) {
        Question q = questionRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Question not found"));
        q.setStatus(Question.QuestionStatus.REMOVED);
        questionRepository.save(q);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/ai/moderate")
    public ResponseEntity<Map<String, Object>> moderateContent(
            @RequestBody Map<String, String> body) {
        AnthropicAIService.ModerationResult result = aiService.moderateContent(body.get("content"));
        return ResponseEntity.ok(Map.of(
            "isToxic", result.isToxic(),
            "isSpam", result.isSpam(),
            "confidence", result.confidence(),
            "reason", result.reason()
        ));
    }
}
