package com.doconnect.dto;

import com.doconnect.entity.ChatMessage;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ChatMessageDto {
    private Long id;
    private String roomId;
    private String content;
    private String senderName;
    private Long senderId;
    private ChatMessage.MessageType type;
    private LocalDateTime createdAt;

    public static ChatMessageDto from(ChatMessage m) {
        ChatMessageDto d = new ChatMessageDto();
        d.id = m.getId();
        d.roomId = m.getRoomId();
        d.content = m.getContent();
        d.senderName = m.getSenderName();
        if (m.getSender() != null) d.senderId = m.getSender().getId();
        d.type = m.getType();
        d.createdAt = m.getCreatedAt();
        return d;
    }
}
