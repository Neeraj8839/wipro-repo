package com.doconnect.repository;

import com.doconnect.entity.Answer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AnswerRepository extends JpaRepository<Answer, Long> {
    List<Answer> findByQuestionIdOrderByVoteCountDesc(Long questionId);
    List<Answer> findByAuthorId(Long authorId);

    @Query("SELECT COUNT(a) FROM Answer a WHERE a.question.id = :questionId AND a.isAiGenerated = true")
    long countAiAnswersByQuestion(@Param("questionId") Long questionId);

    @Query("SELECT COUNT(a) FROM Answer a WHERE a.isModerated = true")
    long countModeratedAnswers();
}
