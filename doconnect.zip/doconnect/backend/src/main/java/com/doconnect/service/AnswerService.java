package com.doconnect.service;

import com.doconnect.dto.AnswerDto;
import com.doconnect.entity.Answer;
import com.doconnect.entity.Notification;
import com.doconnect.entity.Question;
import com.doconnect.entity.User;
import com.doconnect.repository.AnswerRepository;
import com.doconnect.repository.NotificationRepository;
import com.doconnect.repository.QuestionRepository;
import com.doconnect.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AnswerService {

    private final AnswerRepository answerRepository;
    private final QuestionRepository questionRepository;
    private final UserRepository userRepository;
    private final NotificationRepository notificationRepository;
    private final AnthropicAIService aiService;

    @Transactional
    public AnswerDto.Response create(Long questionId, AnswerDto.CreateRequest req, String username) {
        Question question = questionRepository.findById(questionId)
            .orElseThrow(() -> new EntityNotFoundException("Question not found"));
        User author = userRepository.findByUsername(username)
            .orElseThrow(() -> new EntityNotFoundException("User not found"));

        // Moderate the answer
        AnthropicAIService.ModerationResult mod =
            aiService.moderateContent(req.getBody());

        Answer answer = Answer.builder()
            .body(req.getBody())
            .question(question)
            .author(author)
            .isAiGenerated(false)
            .isAccepted(false)
            .voteCount(0)
            .isModerated(mod.isToxic() || mod.isSpam())
            .moderationNote(mod.reason())
            .build();

        Answer saved = answerRepository.save(answer);

        // Notify question author
        if (!question.getAuthor().getId().equals(author.getId())) {
            notificationRepository.save(Notification.builder()
                .user(question.getAuthor())
                .message(author.getDisplayName() + " answered your question: " + question.getTitle())
                .link("/questions/" + questionId)
                .type(Notification.NotificationType.ANSWER)
                .isRead(false)
                .build());
        }

        return AnswerDto.Response.from(saved);
    }

    /**
     * Module 3: Generate AI answer using Anthropic Claude
     */
    @Transactional
    public AnswerDto.Response generateAiAnswer(Long questionId) {
        Question question = questionRepository.findById(questionId)
            .orElseThrow(() -> new EntityNotFoundException("Question not found"));

        String aiBody = aiService.generateAnswer(
            question.getTitle(),
            question.getBody(),
            question.getTags()
        );

        Answer answer = Answer.builder()
            .body(aiBody)
            .question(question)
            .author(null)
            .isAiGenerated(true)
            .isAccepted(false)
            .voteCount(0)
            .build();

        return AnswerDto.Response.from(answerRepository.save(answer));
    }

    public List<AnswerDto.Response> getByQuestion(Long questionId) {
        return answerRepository.findByQuestionIdOrderByVoteCountDesc(questionId)
            .stream().map(AnswerDto.Response::from).collect(Collectors.toList());
    }

    @Transactional
    public AnswerDto.Response accept(Long answerId, String username) {
        Answer answer = answerRepository.findById(answerId)
            .orElseThrow(() -> new EntityNotFoundException("Answer not found"));
        User user = userRepository.findByUsername(username)
            .orElseThrow(() -> new EntityNotFoundException("User not found"));

        if (!answer.getQuestion().getAuthor().getId().equals(user.getId())) {
            throw new RuntimeException("Only question author can accept answers");
        }

        answer.setIsAccepted(true);
        answer.getQuestion().setIsSolved(true);
        questionRepository.save(answer.getQuestion());
        return AnswerDto.Response.from(answerRepository.save(answer));
    }

    @Transactional
    public AnswerDto.Response vote(Long id, int delta) {
        Answer answer = answerRepository.findById(id)
            .orElseThrow(() -> new EntityNotFoundException("Answer not found"));
        answer.setVoteCount(answer.getVoteCount() + delta);
        return AnswerDto.Response.from(answerRepository.save(answer));
    }

    public String summarize(Long answerId) {
        Answer answer = answerRepository.findById(answerId)
            .orElseThrow(() -> new EntityNotFoundException("Answer not found"));
        return aiService.summarize(answer.getBody());
    }

    public String enhanceGrammar(String text) {
        return aiService.enhanceGrammar(text);
    }
}
