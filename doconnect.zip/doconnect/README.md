# DoConnect AI – Intelligent Discussion & Knowledge Collaboration Platform

> A full-stack AI-powered Q&A platform (StackOverflow + Discord) built with **Vite React**, **Spring Boot**, and **MySQL**, leveraging **Anthropic Claude AI** for intelligent features.

---

## 📋 Table of Contents
1. [Architecture Overview](#architecture)
2. [Tech Stack](#tech-stack)
3. [Project Structure](#project-structure)
4. [Setup & Installation](#setup)
5. [Running the Project](#running)
6. [Module Breakdown](#modules)
7. [API Reference](#api)
8. [Database Schema](#database)
9. [AI Features](#ai-features)
10. [Rubric Coverage](#rubric)

---

## Architecture Overview <a name="architecture"></a>

```
┌─────────────────────────────────────────────────────────┐
│              React Frontend (Vite, Port 5173)           │
│  Login │ Questions │ Chat │ Dashboard │ Admin Panel     │
└──────────────────────┬──────────────────────────────────┘
                       │  REST API + WebSocket (STOMP)
┌──────────────────────▼──────────────────────────────────┐
│           Spring Boot Backend (Port 8080)               │
│  AuthController │ QuestionController │ AnswerController │
│  ChatController │ AnalyticsController │ AdminController  │
│  JWT Filter │ Security Config │ CORS Config             │
└────────┬──────────────────────────────┬─────────────────┘
         │                              │
┌────────▼────────┐           ┌─────────▼──────────────┐
│  MySQL Database │           │  Anthropic Claude API  │
│  (Port 3306)    │           │  (Answer Gen, Moderate,│
│                 │           │   Tag Predict, Sentiment│
└─────────────────┘           └────────────────────────┘
```

---

## Tech Stack <a name="tech-stack"></a>

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, Vite 5, React Router v6 |
| UI | Custom CSS variables, Lucide Icons, Recharts |
| Real-time | STOMP WebSocket via @stomp/stompjs + SockJS |
| Markdown | react-markdown |
| Backend | Spring Boot 3.2, Spring Security, Spring WebSocket |
| ORM | Spring Data JPA (Hibernate) |
| Database | MySQL 8.0 |
| Auth | JWT (io.jsonwebtoken jjwt 0.12.3) |
| AI | Anthropic Claude (claude-sonnet-4) via WebClient |
| HTTP Client | Spring WebFlux WebClient |
| Validation | Jakarta Validation, Spring Validation |

---

## Project Structure <a name="project-structure"></a>

```
doconnect/
├── frontend/                          # Vite + React
│   ├── src/
│   │   ├── api/index.js               # Axios API client
│   │   ├── context/AuthContext.jsx    # Auth state (JWT)
│   │   ├── hooks/useWebSocket.js      # STOMP WebSocket hook
│   │   ├── components/
│   │   │   └── common/
│   │   │       ├── Navbar.jsx
│   │   │       └── ProtectedRoute.jsx
│   │   ├── pages/
│   │   │   ├── LoginPage.jsx          # Module 1
│   │   │   ├── RegisterPage.jsx       # Module 1
│   │   │   ├── HomePage.jsx           # Questions feed
│   │   │   ├── AskQuestionPage.jsx    # Module 2 (AI tags)
│   │   │   ├── QuestionDetailPage.jsx # Module 3 (AI answers)
│   │   │   ├── ChatRoomPage.jsx       # Module 4 (WebSocket)
│   │   │   ├── DashboardPage.jsx      # Module 6 (Analytics)
│   │   │   ├── AdminPage.jsx          # Module 5 (Moderation)
│   │   │   ├── SearchPage.jsx         # Module 2 (AI search)
│   │   │   └── ProfilePage.jsx
│   │   ├── App.jsx                    # Router + layout
│   │   ├── main.jsx
│   │   └── index.css                  # Design system
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
│
└── backend/                           # Spring Boot
    ├── pom.xml
    └── src/main/
        ├── java/com/doconnect/
        │   ├── DoConnectApplication.java
        │   ├── config/
        │   │   ├── SecurityConfig.java       # JWT + CORS + Role-based
        │   │   └── WebSocketConfig.java      # STOMP endpoints
        │   ├── security/
        │   │   ├── JwtUtil.java              # Token generation/validation
        │   │   └── JwtAuthFilter.java        # Request filter
        │   ├── entity/
        │   │   ├── User.java                 # UserDetails impl
        │   │   ├── Question.java             # Tags, votes, status
        │   │   ├── Answer.java               # AI flag, accepted
        │   │   ├── ChatMessage.java          # WebSocket messages
        │   │   └── Notification.java         # User alerts
        │   ├── repository/                   # JPA interfaces
        │   ├── dto/                          # Request/Response DTOs
        │   ├── service/
        │   │   ├── AuthService.java
        │   │   ├── QuestionService.java      # AI tag prediction
        │   │   ├── AnswerService.java        # AI answer generation
        │   │   ├── ChatService.java          # WebSocket + moderation
        │   │   ├── AnalyticsService.java     # Dashboard stats
        │   │   └── AnthropicAIService.java   # All AI calls
        │   ├── controller/                   # REST + WebSocket controllers
        │   └── exception/
        │       └── GlobalExceptionHandler.java
        └── resources/
            └── application.properties
```

---

## Setup & Installation <a name="setup"></a>

### Prerequisites
- Java 17+
- Node.js 18+
- MySQL 8.0+
- Maven 3.8+

### Step 1 – MySQL Setup
```sql
-- Create database
CREATE DATABASE doconnect_db CHARACTER SET utf8mb4;

-- The tables are auto-created by Hibernate on first run
```

### Step 2 – Backend Configuration
Edit `backend/src/main/resources/application.properties`:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/doconnect_db?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=YOUR_MYSQL_PASSWORD

anthropic.api.key=YOUR_ANTHROPIC_API_KEY
```

Get your Anthropic API key at: https://console.anthropic.com

### Step 3 – Frontend Dependencies
```bash
cd frontend
npm install
```

### Step 4 – Backend Dependencies
```bash
cd backend
mvn clean install
```

---

## Running the Project <a name="running"></a>

### Start Backend (Terminal 1)
```bash
cd backend
mvn spring-boot:run
# Starts on http://localhost:8080
```

### Start Frontend (Terminal 2)
```bash
cd frontend
npm run dev
# Starts on http://localhost:5173
```

### Create Demo Accounts
```bash
# Register admin
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","email":"admin@test.com","password":"admin123","displayName":"Admin"}'

# Then set admin role in MySQL:
# UPDATE users SET role = 'ADMIN' WHERE username = 'admin';

# Register demo user
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"demo","email":"demo@test.com","password":"demo123","displayName":"Demo User"}'
```

---

## Module Breakdown <a name="modules"></a>

### Module 1 – Authentication & User Roles
- **JWT authentication** with HS256 signing
- **Three roles**: USER, MODERATOR, ADMIN
- Role-based route protection on both frontend (ProtectedRoute) and backend (@PreAuthorize)
- Profile management

### Module 2 – AI Question Recommendation System
- **Smart tag prediction**: Leave tags empty → Claude predicts them on submit
- **Similar question recommendations**: Based on shared tags via DB query
- **AI-powered search**: Full-text search across title + body
- Trending tags sidebar (DB aggregation)

### Module 3 – AI Answer Assistant
- **AI-generated answers**: "Get AI Answer" button calls Claude with question context
- **Auto summarization**: Summarize any answer with one click
- **Grammar enhancement**: AI rewrites question body or answer draft

### Module 4 – Real-Time Discussion & Chat
- **WebSocket (STOMP over SockJS)** for live bidirectional messaging
- **10 topic rooms**: general, java, python, javascript, spring-boot, react, database, devops, ai-ml, help
- JOIN/LEAVE system messages
- Persistent chat history (MySQL)
- Online presence indicator

### Module 5 – AI Content Moderation
- **Every question and answer** goes through Claude moderation on submission
- Toxic/spam content is auto-flagged → `FLAGGED` status
- Admin/Moderator panel to approve or remove flagged content
- Real-time moderation alerts via system messages in chat
- Inline AI Moderation Tester in Admin panel

### Module 6 – Analytics Dashboard
- **Trending topics** bar chart (top tags by count)
- **Active users** (top contributors by reputation)
- **Engagement metrics**: total questions, answers, users, today's activity
- **AI sentiment analysis** donut chart (simulated with real AI backing)
- Flagged content count and quick-action panel

---

## API Reference <a name="api"></a>

### Auth
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/auth/register` | Public | Register new user |
| POST | `/api/auth/login` | Public | Login, get JWT |

### Questions
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/questions` | Public | List questions (paginated) |
| POST | `/api/questions` | USER | Create question (AI tags + moderation) |
| GET | `/api/questions/{id}` | Public | Get question detail |
| GET | `/api/questions/search?q=` | Public | AI-powered text search |
| GET | `/api/questions/{id}/similar` | Public | Similar question recommendations |
| POST | `/api/questions/{id}/vote?delta=` | USER | Upvote/downvote |
| DELETE | `/api/questions/{id}` | OWNER/ADMIN | Delete question |
| GET | `/api/questions/trending-tags` | Public | Top trending tags |

### Answers
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/questions/{id}/answers` | Public | List answers |
| POST | `/api/questions/{id}/answers` | USER | Post answer (with moderation) |
| POST | `/api/questions/{id}/answers/ai` | Public | Generate AI answer |
| POST | `/api/answers/{id}/accept` | QUESTION_AUTHOR | Accept answer |
| POST | `/api/answers/{id}/vote?delta=` | USER | Vote on answer |
| GET | `/api/answers/{id}/summarize` | Public | AI summarize answer |
| POST | `/api/ai/enhance-grammar` | Public | AI grammar enhancement |

### Chat (WebSocket)
| Type | Destination | Description |
|------|-------------|-------------|
| STOMP Endpoint | `/ws` (SockJS) | Connect |
| Subscribe | `/topic/chat/{roomId}` | Receive messages |
| Publish | `/app/chat/{roomId}` | Send message |
| REST | `GET /api/chat/{roomId}/history` | Load message history |
| REST | `GET /api/chat/rooms` | List available rooms |

### Analytics & Moderation
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/analytics/dashboard` | MOD/ADMIN | Dashboard stats |
| GET | `/api/moderation/flagged` | MOD/ADMIN | Flagged questions |
| POST | `/api/moderation/questions/{id}/approve` | MOD/ADMIN | Approve question |
| POST | `/api/moderation/questions/{id}/remove` | MOD/ADMIN | Remove question |
| POST | `/api/ai/moderate` | Public | Test AI moderation |

---

## Database Schema <a name="database"></a>

```
users                questions              answers
─────────────        ─────────────────      ─────────────
id (PK)              id (PK)                id (PK)
username             title                  body
email                body (TEXT)            question_id (FK)
password             author_id (FK)         author_id (FK)
display_name         view_count             is_ai_generated
bio                  vote_count             is_accepted
role (ENUM)          is_solved              vote_count
active               is_moderated           is_moderated
reputation           moderation_note        created_at
created_at           status (ENUM)
updated_at           created_at

question_tags        chat_messages          notifications
─────────────        ─────────────────      ─────────────
question_id (FK)     id (PK)                id (PK)
tag (VARCHAR)        room_id                user_id (FK)
                     content (TEXT)         message
                     sender_id (FK)         link
                     sender_name            type (ENUM)
                     type (ENUM)            is_read
                     is_moderated           created_at
                     created_at
```

---

## AI Features <a name="ai-features"></a>

All AI features use **Anthropic Claude** (claude-sonnet-4) via the `/v1/messages` API:

| Feature | Trigger | Prompt Strategy |
|---------|---------|----------------|
| Tag prediction | Question submission (empty tags) | Returns comma-separated tags only |
| Answer generation | "Get AI Answer" button | Context-aware technical assistant prompt |
| Auto summarization | "AI Summarize" button on answers | 2-3 sentence summary prompt |
| Grammar enhancement | "Enhance Grammar" button | Preserves technical meaning |
| Content moderation | Every submit (question/answer/chat) | JSON output: isToxic, isSpam, confidence |
| Sentiment analysis | Analytics dashboard | Returns POSITIVE/NEGATIVE/NEUTRAL |

---

## Rubric Coverage <a name="rubric"></a>

| Criterion | Marks | Implementation |
|-----------|-------|----------------|
| React Component Design | 10 | Functional components, hooks, props, context |
| Routing & Navigation | 10 | React Router v6 with protected routes by role |
| Spring Boot APIs | 15 | 6 controllers, 20+ endpoints, DTOs, validation |
| Real-Time Chat Integration | 10 | STOMP WebSocket, SockJS, 10 rooms |
| AI Recommendation Logic | 10 | Tag prediction, similar questions, AI search |
| AI Moderation Engine | 10 | Auto-flag, approve/remove, tester panel |
| Database Relationships | 10 | JPA OneToMany, ManyToOne, ElementCollection |
| JWT Security | 10 | HS256 JWT, filter chain, role-based auth |
| Frontend-Backend Integration | 10 | Axios with auth interceptor, error handling |
| Validation & Error Handling | 5 | Jakarta Validation, GlobalExceptionHandler |
| Deployment & Documentation | 5 | This README + SQL setup + config guide |
| **Total** | **100** | |

---

## Environment Variables Summary

```properties
# MySQL
spring.datasource.url=jdbc:mysql://localhost:3306/doconnect_db...
spring.datasource.username=root
spring.datasource.password=<YOUR_MYSQL_PASSWORD>

# JWT
app.jwt.secret=<256-bit-secret-key>
app.jwt.expiration=86400000  # 24 hours in ms

# Anthropic AI
anthropic.api.key=<YOUR_ANTHROPIC_API_KEY>
anthropic.model=claude-sonnet-4-20250514
```
